import { TemplateRef, EventEmitter, ElementRef, type OnInit } from '@angular/core';
import { type ModePreference, type ThemeConfiguration, type ThemeExportFormat, type TokenSelection, themePickerMarkers, type ThemePickerStore, type ThemePickerView, type Target, type BorderKind, type ThemeOptions, type ThemeStore, type Theme, type Role, type PaletteOptions, type PaletteClasses, type Shade } from '@sebytza23/theme-kit';
import * as i0 from "@angular/core";
export * from '@sebytza23/theme-kit';
export declare class ThemeContext {
    private current;
    private listeners;
    private forward;
    private unsubscribe;
    readonly store: ThemeStore;
    constructor();
    configure(store: ThemeStore): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeContext, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ThemeContext>;
}
export declare function useThemeStore(): ThemeStore;
export declare function useTheme(): import("@angular/core").Signal<import("@sebytza23/theme-kit-angular").ThemeSnapshot>;
export declare class ThemeProvider implements OnInit {
    options: ThemeOptions;
    store?: ThemeStore;
    private context;
    private destroyRef;
    readonly state: import("@angular/core").WritableSignal<import("@sebytza23/theme-kit-angular").ThemeSnapshot>;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeProvider, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThemeProvider, "tk-provider", never, { "options": { "alias": "options"; "required": false; }; "store": { "alias": "store"; "required": false; }; }, {}, never, ["*"], true, never>;
}
export declare class ThemeLoading {
    readonly state: import("@angular/core").Signal<import("@sebytza23/theme-kit-angular").ThemeSnapshot>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeLoading, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThemeLoading, "tk-loading", never, {}, {}, never, ["*"], true, never>;
}
export declare class ThemeReady {
    readonly state: import("@angular/core").Signal<import("@sebytza23/theme-kit-angular").ThemeSnapshot>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeReady, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThemeReady, "tk-ready", never, {}, {}, never, ["*"], true, never>;
}
export declare class ThemeError {
    readonly state: import("@angular/core").Signal<import("@sebytza23/theme-kit-angular").ThemeSnapshot>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeError, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThemeError, "tk-error", never, {}, {}, never, ["*"], true, never>;
}
export declare class ThemeSwatch {
    theme: Theme;
    readonly state: import("@angular/core").Signal<import("@sebytza23/theme-kit-angular").ThemeSnapshot>;
    readonly store: ThemeStore;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeSwatch, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThemeSwatch, "tk-swatch", never, { "theme": { "alias": "theme"; "required": true; }; }, {}, never, never, true, never>;
}
export declare function useThemeMode(): {
    setMode: (mode: ModePreference) => void;
    cycle: () => void;
    preference: import("@angular/core").Signal<"light" | "dark" | "system">;
    resolvedMode: import("@angular/core").Signal<import("@sebytza23/theme-kit-angular").Mode>;
};
export declare class ThemeMode {
    value?: ModePreference;
    labels: Record<ModePreference, string>;
    content?: TemplateRef<unknown>;
    readonly mode: {
        setMode: (mode: ModePreference) => void;
        cycle: () => void;
        preference: import("@angular/core").Signal<"light" | "dark" | "system">;
        resolvedMode: import("@angular/core").Signal<import("@sebytza23/theme-kit-angular").Mode>;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeMode, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThemeMode, "tk-mode", never, { "value": { "alias": "value"; "required": false; }; "labels": { "alias": "labels"; "required": false; }; }, {}, ["content"], never, true, never>;
}
export declare class ThemeName {
    label: string;
    content?: TemplateRef<unknown>;
    readonly store: ThemeStore;
    readonly state: import("@angular/core").Signal<import("@sebytza23/theme-kit-angular").ThemeSnapshot>;
    readonly suggestion: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeName, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThemeName, "tk-name", never, { "label": { "alias": "label"; "required": false; }; }, {}, ["content"], never, true, never>;
}
export declare class ThemePalette {
    role: Role;
    shape: PaletteOptions['shape'];
    classes: PaletteClasses;
    labels: Partial<Record<Shade, string>>;
    shadeClasses: Partial<Record<Shade, string>>;
    readonly shades: readonly [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950];
    readonly state: import("@angular/core").Signal<import("@sebytza23/theme-kit-angular").ThemeSnapshot>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemePalette, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThemePalette, "tk-palette", never, { "role": { "alias": "role"; "required": false; }; "shape": { "alias": "shape"; "required": false; }; "classes": { "alias": "classes"; "required": false; }; "labels": { "alias": "labels"; "required": false; }; "shadeClasses": { "alias": "shadeClasses"; "required": false; }; }, {}, never, never, true, never>;
}
export declare class ThemeGenerator {
    ngOnChanges(): void;
    private registration?;
    constructor();
    disabled: boolean;
    role: Role;
    wheel: boolean;
    custom: boolean;
    readonly state: import("@angular/core").Signal<import("@sebytza23/theme-kit-angular").ThemeSnapshot>;
    readonly store: ThemeStore;
    seed(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeGenerator, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThemeGenerator, "tk-generator,tk-color", never, { "disabled": { "alias": "disabled"; "required": false; }; "role": { "alias": "role"; "required": false; }; "wheel": { "alias": "wheel"; "required": false; }; "custom": { "alias": "custom"; "required": false; }; }, {}, never, ["*"], true, never>;
}
export declare class ThemeBackground {
    ngOnChanges(): void;
    private registration?;
    constructor();
    label: string;
    readonly state: import("@angular/core").Signal<import("@sebytza23/theme-kit-angular").ThemeSnapshot>;
    readonly store: ThemeStore;
    change(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeBackground, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThemeBackground, "tk-background", never, { "label": { "alias": "label"; "required": false; }; }, {}, never, never, true, never>;
}
export { ThemeGenerator as ThemeColor };
export declare class ThemeHarmony {
    label: string;
    select: ElementRef<HTMLSelectElement>;
    readonly harmonies: readonly ["analogous", "triadic", "split-complementary"];
    readonly state: import("@angular/core").Signal<import("@sebytza23/theme-kit-angular").ThemeSnapshot>;
    readonly store: ThemeStore;
    constructor();
    change(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeHarmony, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThemeHarmony, "tk-harmony", never, { "label": { "alias": "label"; "required": false; }; }, {}, never, never, true, never>;
}
export declare class ThemeBorder {
    ngOnChanges(): void;
    private registration?;
    constructor();
    kind: BorderKind;
    target: Target;
    label: string;
    readonly state: import("@angular/core").Signal<import("@sebytza23/theme-kit-angular").ThemeSnapshot>;
    readonly store: ThemeStore;
    change(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeBorder, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThemeBorder, "tk-border", never, { "kind": { "alias": "kind"; "required": false; }; "target": { "alias": "target"; "required": false; }; "label": { "alias": "label"; "required": false; }; }, {}, never, never, true, never>;
}
export declare class ThemeRadius {
    target: Target;
    label: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeRadius, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThemeRadius, "tk-radius", never, { "target": { "alias": "target"; "required": false; }; "label": { "alias": "label"; "required": false; }; }, {}, never, never, true, never>;
}
export declare class ThemeBorderWidth {
    target: Target;
    label: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeBorderWidth, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThemeBorderWidth, "tk-border-width", never, { "target": { "alias": "target"; "required": false; }; "label": { "alias": "label"; "required": false; }; }, {}, never, never, true, never>;
}
export declare class ThemeWheel implements OnInit {
    picker: ThemePickerStore;
    readonly state: import("@angular/core").WritableSignal<import("@sebytza23/theme-kit-angular").ThemePickerSnapshot | null>;
    readonly themePickerMarkers: typeof themePickerMarkers;
    private destroy;
    ngOnInit(): void;
    select(id: string): void;
    change(event: {
        id: string;
        hsv: Partial<import('@sebytza23/color-picker').HSV>;
    }): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeWheel, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThemeWheel, "tk-wheel", never, { "picker": { "alias": "picker"; "required": true; }; }, {}, never, never, true, never>;
}
export declare class ThemePicker implements OnInit {
    disabled?: boolean;
    controls?: boolean;
    roles: readonly Role[];
    activeRole?: Role;
    view: ThemePickerView;
    store?: ThemePickerStore;
    custom: boolean;
    viewSelect?: ElementRef<HTMLSelectElement>;
    picker: ThemePickerStore;
    readonly state: import("@angular/core").WritableSignal<import("@sebytza23/theme-kit-angular").ThemePickerSnapshot | null>;
    readonly allRoles: readonly ["primary", "secondary", "accent"];
    readonly views: readonly ["area", "wheel", "shared-wheel"];
    private theme;
    private destroy;
    constructor();
    ngOnInit(): void;
    changeView(event: Event): void;
    toggle(role: Role, event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemePicker, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThemePicker, "tk-picker", never, { "disabled": { "alias": "disabled"; "required": false; }; "controls": { "alias": "controls"; "required": false; }; "roles": { "alias": "roles"; "required": false; }; "activeRole": { "alias": "activeRole"; "required": false; }; "view": { "alias": "view"; "required": false; }; "store": { "alias": "store"; "required": false; }; "custom": { "alias": "custom"; "required": false; }; }, {}, never, ["*"], true, never>;
}
export declare class ThemeSelect {
    themes: readonly Theme[];
    label: string;
    select: ElementRef<HTMLSelectElement>;
    readonly store: ThemeStore;
    readonly state: import("@angular/core").Signal<import("@sebytza23/theme-kit-angular").ThemeSnapshot>;
    list(): readonly Theme[];
    value(): string;
    choose(event: Event): void;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeSelect, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThemeSelect, "tk-select", never, { "themes": { "alias": "themes"; "required": false; }; "label": { "alias": "label"; "required": false; }; }, {}, never, never, true, never>;
}
export declare class ThemeExport {
    format: ThemeExportFormat;
    private selectionKey;
    set selection(value: TokenSelection | undefined);
    get selection(): TokenSelection | undefined;
    custom: boolean;
    configurationChange: EventEmitter<ThemeConfiguration>;
    readonly state: import("@angular/core").Signal<import("@sebytza23/theme-kit-angular").ThemeSnapshot>;
    configuration(): ThemeConfiguration;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<ThemeExport, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThemeExport, "tk-export", never, { "format": { "alias": "format"; "required": false; }; "selection": { "alias": "selection"; "required": false; }; "custom": { "alias": "custom"; "required": false; }; }, { "configurationChange": "configurationChange"; }, never, ["*"], true, never>;
}
