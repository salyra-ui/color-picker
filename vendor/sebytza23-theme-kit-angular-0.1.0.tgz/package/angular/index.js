import { NgTemplateOutlet } from '@angular/common';
import { ContentChild, TemplateRef, computed, Component, Output, EventEmitter, afterRenderEffect, ViewChild, Injectable, Input, inject, signal, DestroyRef, afterNextRender, } from '@angular/core';
import { ColorSurface, ColorViewSelect, ColorWheel, ColorFormatSelect, ColorMode, ColorProvider, ColorArea, ColorSlider, ColorInput, } from '@sebytza23/color-picker-angular';
import { channelsToHex } from '@sebytza23/color-picker';
import { themeModeActions, suggestedThemeName, themeList, selectedThemeId, themeConfiguration, themePickerMarkers, createThemePickerStore, themePickerViews, roles as allRoles, harmonies, createThemeStore, mountThemeStore, shades, } from '@sebytza23/theme-kit';
import * as i0 from "@angular/core";
export * from '@sebytza23/theme-kit';
export class ThemeContext {
    constructor() {
        this.current = createThemeStore();
        this.listeners = new Set();
        this.forward = () => this.listeners.forEach((fn) => fn());
        this.unsubscribe = this.current.subscribe(this.forward);
        this.store = {
            getSnapshot: () => this.current.getSnapshot(),
            getServerSnapshot: () => this.current.getServerSnapshot(),
            subscribe: (fn) => {
                this.listeners.add(fn);
                return () => {
                    this.listeners.delete(fn);
                };
            },
            start: () => this.current.start(),
            reload: () => this.current.reload(),
            stop: () => this.current.stop(),
            setTheme: (theme) => this.current.setTheme(theme),
            registerFields: (selection) => this.current.registerFields(selection),
            setDisabled: (disabled) => this.current.setDisabled(disabled),
            setSelection: (selection) => this.current.setSelection(selection),
            setBackground: (mode) => this.current.setBackground(mode),
            setMode: (mode) => this.current.setMode(mode),
            setSystemMode: (mode) => this.current.setSystemMode(mode),
            setName: (name) => this.current.setName(name),
            generate: (seed, options) => this.current.generate(seed, options),
            setColor: (role, hex) => this.current.setColor(role, hex),
            setBorder: (kind, target, value) => this.current.setBorder(kind, target, value),
            setHarmony: (value) => this.current.setHarmony(value),
            generateHarmony: () => this.current.generateHarmony(),
        };
        inject(DestroyRef).onDestroy(() => this.unsubscribe());
    }
    configure(store) {
        this.unsubscribe();
        this.current = store;
        this.unsubscribe = store.subscribe(this.forward);
        this.forward();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeContext, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeContext }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeContext, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });
export function useThemeStore() {
    return inject(ThemeContext).store;
}
export function useTheme() {
    const store = useThemeStore(), state = signal(store.getSnapshot());
    inject(DestroyRef).onDestroy(store.subscribe(() => state.set(store.getSnapshot())));
    return state.asReadonly();
}
export class ThemeProvider {
    constructor() {
        this.options = {};
        this.context = inject(ThemeContext);
        this.destroyRef = inject(DestroyRef);
        this.state = signal(this.context.store.getSnapshot());
        let cleanup;
        afterNextRender(() => {
            cleanup = mountThemeStore(this.context.store, this.options.storage, this.options);
        });
        this.destroyRef.onDestroy(() => cleanup?.());
    }
    ngOnInit() {
        this.context.configure(this.store ?? createThemeStore(this.options));
        this.state.set(this.context.store.getSnapshot());
        this.destroyRef.onDestroy(this.context.store.subscribe(() => this.state.set(this.context.store.getSnapshot())));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeProvider, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: ThemeProvider, isStandalone: true, selector: "tk-provider", inputs: { options: "options", store: "store" }, providers: [ThemeContext], ngImport: i0, template: `<div
    class="tk-scope"
    [attr.data-disabled]="state().disabled"
    [attr.data-theme]="state().theme.id"
    [attr.data-mode]="state().mode"
    [attr.data-mode-preference]="state().modePreference"
    [attr.data-theme-status]="state().status"
    [style]="state().style"
  >
    <fieldset
      class="tk-provider-controls"
      [disabled]="state().disabled"
      [attr.inert]="state().disabled ? '' : null"
      [attr.aria-disabled]="state().disabled"
    >
      <ng-content />
    </fieldset>
  </div>`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeProvider, decorators: [{
            type: Component,
            args: [{
                    selector: 'tk-provider',
                    standalone: true,
                    providers: [ThemeContext],
                    template: `<div
    class="tk-scope"
    [attr.data-disabled]="state().disabled"
    [attr.data-theme]="state().theme.id"
    [attr.data-mode]="state().mode"
    [attr.data-mode-preference]="state().modePreference"
    [attr.data-theme-status]="state().status"
    [style]="state().style"
  >
    <fieldset
      class="tk-provider-controls"
      [disabled]="state().disabled"
      [attr.inert]="state().disabled ? '' : null"
      [attr.aria-disabled]="state().disabled"
    >
      <ng-content />
    </fieldset>
  </div>`,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input
            }], store: [{
                type: Input
            }] } });
export class ThemeLoading {
    constructor() {
        this.state = useTheme();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeLoading, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ThemeLoading, isStandalone: true, selector: "tk-loading", ngImport: i0, template: `@if (state().status === 'loading') {
    <ng-content />
  }`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeLoading, decorators: [{
            type: Component,
            args: [{
                    selector: 'tk-loading',
                    standalone: true,
                    template: `@if (state().status === 'loading') {
    <ng-content />
  }`,
                }]
        }] });
export class ThemeReady {
    constructor() {
        this.state = useTheme();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeReady, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ThemeReady, isStandalone: true, selector: "tk-ready", ngImport: i0, template: `@if (state().status !== 'loading') {
    <ng-content />
  }`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeReady, decorators: [{
            type: Component,
            args: [{
                    selector: 'tk-ready',
                    standalone: true,
                    template: `@if (state().status !== 'loading') {
    <ng-content />
  }`,
                }]
        }] });
export class ThemeError {
    constructor() {
        this.state = useTheme();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeError, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ThemeError, isStandalone: true, selector: "tk-error", ngImport: i0, template: `@if (state().error) {
    <ng-content />
  }`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeError, decorators: [{
            type: Component,
            args: [{
                    selector: 'tk-error',
                    standalone: true,
                    template: `@if (state().error) {
    <ng-content />
  }`,
                }]
        }] });
export class ThemeSwatch {
    constructor() {
        this.state = useTheme();
        this.store = useThemeStore();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeSwatch, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: ThemeSwatch, isStandalone: true, selector: "tk-swatch", inputs: { theme: "theme" }, ngImport: i0, template: `<button
    type="button"
    [attr.aria-pressed]="state().theme.id === theme.id"
    (click)="store.setTheme(theme)"
  >
    {{ theme.name }}
  </button>`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeSwatch, decorators: [{
            type: Component,
            args: [{
                    selector: 'tk-swatch',
                    standalone: true,
                    template: `<button
    type="button"
    [attr.aria-pressed]="state().theme.id === theme.id"
    (click)="store.setTheme(theme)"
  >
    {{ theme.name }}
  </button>`,
                }]
        }], propDecorators: { theme: [{
                type: Input,
                args: [{ required: true }]
            }] } });
export function useThemeMode() {
    const store = useThemeStore(), state = useTheme();
    return {
        preference: computed(() => state().modePreference),
        resolvedMode: computed(() => state().mode),
        ...themeModeActions(store),
    };
}
export class ThemeMode {
    constructor() {
        this.labels = {
            system: 'System',
            light: 'Light mode',
            dark: 'Dark mode',
        };
        this.mode = useThemeMode();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeMode, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ThemeMode, isStandalone: true, selector: "tk-mode", inputs: { value: "value", labels: "labels" }, queries: [{ propertyName: "content", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: `<button
    type="button"
    [attr.aria-pressed]="value ? mode.preference() === value : null"
    (click)="value ? mode.setMode(value) : mode.cycle()"
  >
    @if (content) {
      <ng-container
        [ngTemplateOutlet]="content"
        [ngTemplateOutletContext]="{ $implicit: mode }"
      />
    } @else {
      {{ labels[value ?? mode.preference()] }}
    }
  </button>`, isInline: true, dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeMode, decorators: [{
            type: Component,
            args: [{
                    selector: 'tk-mode',
                    standalone: true,
                    imports: [NgTemplateOutlet],
                    template: `<button
    type="button"
    [attr.aria-pressed]="value ? mode.preference() === value : null"
    (click)="value ? mode.setMode(value) : mode.cycle()"
  >
    @if (content) {
      <ng-container
        [ngTemplateOutlet]="content"
        [ngTemplateOutletContext]="{ $implicit: mode }"
      />
    } @else {
      {{ labels[value ?? mode.preference()] }}
    }
  </button>`,
                }]
        }], propDecorators: { value: [{
                type: Input
            }], labels: [{
                type: Input
            }], content: [{
                type: ContentChild,
                args: [TemplateRef]
            }] } });
export class ThemeName {
    constructor() {
        this.label = 'Theme name';
        this.store = useThemeStore();
        this.state = useTheme();
        this.suggestion = computed(() => suggestedThemeName(this.state().theme));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeName, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ThemeName, isStandalone: true, selector: "tk-name", inputs: { label: "label" }, queries: [{ propertyName: "content", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: `@if (content) {
      <ng-container
        [ngTemplateOutlet]="content"
        [ngTemplateOutletContext]="{
          name: state().theme.name,
          suggestedName: suggestion(),
          setName: store.setName,
        }"
      />
    } @else {
      <label class="tk-name"
        >{{ label
        }}<input
          maxlength="200"
          [value]="state().theme.name"
          [placeholder]="suggestion()"
          (blur)="!$any($event.target).value && store.setName()"
          (input)="store.setName($any($event.target).value)"
        /><small>Suggested: {{ suggestion() }}</small></label
      >
    }`, isInline: true, dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeName, decorators: [{
            type: Component,
            args: [{
                    selector: 'tk-name',
                    standalone: true,
                    imports: [NgTemplateOutlet],
                    template: `@if (content) {
      <ng-container
        [ngTemplateOutlet]="content"
        [ngTemplateOutletContext]="{
          name: state().theme.name,
          suggestedName: suggestion(),
          setName: store.setName,
        }"
      />
    } @else {
      <label class="tk-name"
        >{{ label
        }}<input
          maxlength="200"
          [value]="state().theme.name"
          [placeholder]="suggestion()"
          (blur)="!$any($event.target).value && store.setName()"
          (input)="store.setName($any($event.target).value)"
        /><small>Suggested: {{ suggestion() }}</small></label
      >
    }`,
                }]
        }], propDecorators: { label: [{
                type: Input
            }], content: [{
                type: ContentChild,
                args: [TemplateRef]
            }] } });
export class ThemePalette {
    constructor() {
        this.role = 'primary';
        this.shape = 'square';
        this.classes = {};
        this.labels = {};
        this.shadeClasses = {};
        this.shades = shades;
        this.state = useTheme();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemePalette, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ThemePalette, isStandalone: true, selector: "tk-palette", inputs: { role: "role", shape: "shape", classes: "classes", labels: "labels", shadeClasses: "shadeClasses" }, ngImport: i0, template: `<div
    [class]="'tk-palette ' + (classes.root ?? '')"
    [attr.data-shape]="shape"
    [attr.aria-label]="role + ' shades'"
  >
    @for (shade of shades; track shade) {
      <div
        data-palette-part="item"
        [class]="(classes.item ?? '') + ' ' + (shadeClasses[shade] ?? '')"
      >
        <span data-palette-part="label" [class]="classes.label">{{
          labels[shade] ?? shade
        }}</span>
        <div
          data-palette-part="swatch"
          [class]="'tk-shade ' + (classes.swatch ?? '')"
          [style.background]="
            'hsl(' + state().theme.structure.userPreset[role][shade] + ')'
          "
        ></div>
      </div>
    }
  </div>`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemePalette, decorators: [{
            type: Component,
            args: [{
                    selector: 'tk-palette',
                    standalone: true,
                    template: `<div
    [class]="'tk-palette ' + (classes.root ?? '')"
    [attr.data-shape]="shape"
    [attr.aria-label]="role + ' shades'"
  >
    @for (shade of shades; track shade) {
      <div
        data-palette-part="item"
        [class]="(classes.item ?? '') + ' ' + (shadeClasses[shade] ?? '')"
      >
        <span data-palette-part="label" [class]="classes.label">{{
          labels[shade] ?? shade
        }}</span>
        <div
          data-palette-part="swatch"
          [class]="'tk-shade ' + (classes.swatch ?? '')"
          [style.background]="
            'hsl(' + state().theme.structure.userPreset[role][shade] + ')'
          "
        ></div>
      </div>
    }
  </div>`,
                }]
        }], propDecorators: { role: [{
                type: Input
            }], shape: [{
                type: Input
            }], classes: [{
                type: Input
            }], labels: [{
                type: Input
            }], shadeClasses: [{
                type: Input
            }] } });
export class ThemeGenerator {
    ngOnChanges() {
        this.registration?.update({ roles: [this.role] });
    }
    constructor() {
        this.disabled = false;
        this.role = 'primary';
        this.wheel = false;
        this.custom = false;
        this.state = useTheme();
        this.store = useThemeStore();
        afterRenderEffect(() => {
            const selection = { roles: [this.role] };
            if (this.registration)
                this.registration.update(selection);
            else
                this.registration = this.store.registerFields(selection);
        });
        inject(DestroyRef).onDestroy(() => this.registration?.destroy());
    }
    seed() {
        return channelsToHex(this.state().theme.structure.userPreset[this.role].DEFAULT);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeGenerator, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ThemeGenerator, isStandalone: true, selector: "tk-generator,tk-color", inputs: { disabled: "disabled", role: "role", wheel: "wheel", custom: "custom" }, usesOnChanges: true, ngImport: i0, template: `<cp-provider
    [disabled]="disabled || state().disabled"
    [view]="wheel ? 'wheel' : 'area'"
    [value]="seed()"
    (colorChange)="store.setColor(role, $event)"
    ><div class="tk-generator">
      @if (custom) {
        <ng-content />
      } @else {
        <cp-view-select /><cp-surface />
        <cp-format-select /><cp-input /><cp-mode />
      }</div
  ></cp-provider>`, isInline: true, dependencies: [{ kind: "component", type: ColorSurface, selector: "cp-surface" }, { kind: "component", type: ColorViewSelect, selector: "cp-view-select", inputs: ["label"] }, { kind: "component", type: ColorProvider, selector: "cp-provider", inputs: ["value", "disabled", "view", "store"], outputs: ["colorChange"] }, { kind: "component", type: ColorInput, selector: "cp-input", inputs: ["classes", "className", "format", "label"] }, { kind: "component", type: ColorMode, selector: "cp-mode" }, { kind: "component", type: ColorFormatSelect, selector: "cp-format-select", inputs: ["label"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeGenerator, decorators: [{
            type: Component,
            args: [{
                    selector: 'tk-generator,tk-color',
                    standalone: true,
                    imports: [
                        ColorSurface,
                        ColorViewSelect,
                        ColorProvider,
                        ColorInput,
                        ColorMode,
                        ColorFormatSelect,
                    ],
                    template: `<cp-provider
    [disabled]="disabled || state().disabled"
    [view]="wheel ? 'wheel' : 'area'"
    [value]="seed()"
    (colorChange)="store.setColor(role, $event)"
    ><div class="tk-generator">
      @if (custom) {
        <ng-content />
      } @else {
        <cp-view-select /><cp-surface />
        <cp-format-select /><cp-input /><cp-mode />
      }</div
  ></cp-provider>`,
                }]
        }], ctorParameters: () => [], propDecorators: { disabled: [{
                type: Input
            }], role: [{
                type: Input
            }], wheel: [{
                type: Input
            }], custom: [{
                type: Input
            }] } });
export class ThemeBackground {
    ngOnChanges() {
        this.registration?.update({ roles: [], background: true });
    }
    constructor() {
        this.label = 'Tint background with primary';
        this.state = useTheme();
        this.store = useThemeStore();
        afterRenderEffect(() => {
            const selection = { roles: [], background: true };
            if (this.registration)
                this.registration.update(selection);
            else
                this.registration = this.store.registerFields(selection);
        });
        inject(DestroyRef).onDestroy(() => this.registration?.destroy());
    }
    change(event) {
        this.store.setBackground(event.target.checked ? 'tinted' : 'neutral');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeBackground, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: ThemeBackground, isStandalone: true, selector: "tk-background", inputs: { label: "label" }, usesOnChanges: true, ngImport: i0, template: `<label class="tk-background"
    ><input
      type="checkbox"
      [checked]="state().background === 'tinted'"
      (change)="change($event)"
    />{{ label }}</label
  >`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeBackground, decorators: [{
            type: Component,
            args: [{
                    selector: 'tk-background',
                    standalone: true,
                    template: `<label class="tk-background"
    ><input
      type="checkbox"
      [checked]="state().background === 'tinted'"
      (change)="change($event)"
    />{{ label }}</label
  >`,
                }]
        }], ctorParameters: () => [], propDecorators: { label: [{
                type: Input
            }] } });
export { ThemeGenerator as ThemeColor };
export class ThemeHarmony {
    constructor() {
        this.label = 'Color harmony';
        this.harmonies = harmonies;
        this.state = useTheme();
        this.store = useThemeStore();
        afterRenderEffect(() => {
            const value = this.state().theme.harmony ?? 'analogous';
            if (this.select)
                this.select.nativeElement.value = value;
        });
    }
    change(event) {
        this.store.setHarmony(event.target.value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeHarmony, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ThemeHarmony, isStandalone: true, selector: "tk-harmony", inputs: { label: "label" }, viewQueries: [{ propertyName: "select", first: true, predicate: ["select"], descendants: true }], ngImport: i0, template: `<div class="tk-harmony">
    <label
      >{{ label
      }}<select #select (change)="change($event)">
        @for (value of harmonies; track value) {
          <option
            [value]="value"
            [attr.selected]="
              (state().theme.harmony ?? 'analogous') === value ? '' : null
            "
          >
            {{ value }}
          </option>
        }
      </select></label
    ><button type="button" (click)="store.generateHarmony()">
      Generate accent &amp; secondary
    </button>
  </div>`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeHarmony, decorators: [{
            type: Component,
            args: [{
                    selector: 'tk-harmony',
                    standalone: true,
                    template: `<div class="tk-harmony">
    <label
      >{{ label
      }}<select #select (change)="change($event)">
        @for (value of harmonies; track value) {
          <option
            [value]="value"
            [attr.selected]="
              (state().theme.harmony ?? 'analogous') === value ? '' : null
            "
          >
            {{ value }}
          </option>
        }
      </select></label
    ><button type="button" (click)="store.generateHarmony()">
      Generate accent &amp; secondary
    </button>
  </div>`,
                }]
        }], ctorParameters: () => [], propDecorators: { label: [{
                type: Input
            }], select: [{
                type: ViewChild,
                args: ['select']
            }] } });
export class ThemeBorder {
    ngOnChanges() {
        this.registration?.update({ roles: [], [this.kind]: [this.target] });
    }
    constructor() {
        this.kind = 'width';
        this.target = 'DEFAULT';
        this.label = '';
        this.state = useTheme();
        this.store = useThemeStore();
        afterRenderEffect(() => {
            const selection = { roles: [], [this.kind]: [this.target] };
            if (this.registration)
                this.registration.update(selection);
            else
                this.registration = this.store.registerFields(selection);
        });
        inject(DestroyRef).onDestroy(() => this.registration?.destroy());
    }
    change(event) {
        const n = event.target.valueAsNumber;
        if (Number.isFinite(n) && n >= 0 && n <= 1000)
            this.store.setBorder(this.kind, this.target, n);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeBorder, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: ThemeBorder, isStandalone: true, selector: "tk-border", inputs: { kind: "kind", target: "target", label: "label" }, usesOnChanges: true, ngImport: i0, template: `<label class="tk-border"
    >{{ label || target + ' border ' + kind
    }}<input
      type="number"
      min="0"
      max="1000"
      [step]="kind === 'width' ? 1 : 0.125"
      [value]="state().theme.structure.websitePreset.border[kind][target]"
      (input)="change($event)"
    />{{ kind === 'width' ? 'px' : 'rem' }}</label
  >`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeBorder, decorators: [{
            type: Component,
            args: [{
                    selector: 'tk-border',
                    standalone: true,
                    template: `<label class="tk-border"
    >{{ label || target + ' border ' + kind
    }}<input
      type="number"
      min="0"
      max="1000"
      [step]="kind === 'width' ? 1 : 0.125"
      [value]="state().theme.structure.websitePreset.border[kind][target]"
      (input)="change($event)"
    />{{ kind === 'width' ? 'px' : 'rem' }}</label
  >`,
                }]
        }], ctorParameters: () => [], propDecorators: { kind: [{
                type: Input
            }], target: [{
                type: Input
            }], label: [{
                type: Input
            }] } });
export class ThemeRadius {
    constructor() {
        this.target = 'DEFAULT';
        this.label = '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeRadius, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: ThemeRadius, isStandalone: true, selector: "tk-radius", inputs: { target: "target", label: "label" }, ngImport: i0, template: `<tk-border kind="radius" [target]="target" [label]="label" />`, isInline: true, dependencies: [{ kind: "component", type: ThemeBorder, selector: "tk-border", inputs: ["kind", "target", "label"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeRadius, decorators: [{
            type: Component,
            args: [{
                    selector: 'tk-radius',
                    standalone: true,
                    imports: [ThemeBorder],
                    template: `<tk-border kind="radius" [target]="target" [label]="label" />`,
                }]
        }], propDecorators: { target: [{
                type: Input
            }], label: [{
                type: Input
            }] } });
export class ThemeBorderWidth {
    constructor() {
        this.target = 'DEFAULT';
        this.label = '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeBorderWidth, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.25", type: ThemeBorderWidth, isStandalone: true, selector: "tk-border-width", inputs: { target: "target", label: "label" }, ngImport: i0, template: `<tk-border kind="width" [target]="target" [label]="label" />`, isInline: true, dependencies: [{ kind: "component", type: ThemeBorder, selector: "tk-border", inputs: ["kind", "target", "label"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeBorderWidth, decorators: [{
            type: Component,
            args: [{
                    selector: 'tk-border-width',
                    standalone: true,
                    imports: [ThemeBorder],
                    template: `<tk-border kind="width" [target]="target" [label]="label" />`,
                }]
        }], propDecorators: { target: [{
                type: Input
            }], label: [{
                type: Input
            }] } });
export class ThemeWheel {
    constructor() {
        this.state = signal(null);
        this.themePickerMarkers = themePickerMarkers;
        this.destroy = inject(DestroyRef);
    }
    ngOnInit() {
        this.state.set(this.picker.getSnapshot());
        this.destroy.onDestroy(this.picker.subscribe(() => this.state.set(this.picker.getSnapshot())));
    }
    select(id) {
        this.picker.selectRole(id);
    }
    change(event) {
        this.picker.setHSV(event.id, event.hsv);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeWheel, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ThemeWheel, isStandalone: true, selector: "tk-wheel", inputs: { picker: "picker" }, ngImport: i0, template: `@if (state(); as s) {
    <cp-wheel
      className="tk-shared-wheel"
      label="Shared theme color wheel"
      [markers]="themePickerMarkers(s)"
      [activeId]="s.activeRole"
      (markerSelect)="select($event)"
      (markerChange)="change($event)"
    />
  }`, isInline: true, dependencies: [{ kind: "component", type: ColorWheel, selector: "cp-wheel", inputs: ["label", "className", "classes", "thumbText", "markers", "activeId"], outputs: ["markerSelect", "markerChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeWheel, decorators: [{
            type: Component,
            args: [{
                    selector: 'tk-wheel',
                    standalone: true,
                    imports: [ColorWheel],
                    template: `@if (state(); as s) {
    <cp-wheel
      className="tk-shared-wheel"
      label="Shared theme color wheel"
      [markers]="themePickerMarkers(s)"
      [activeId]="s.activeRole"
      (markerSelect)="select($event)"
      (markerChange)="change($event)"
    />
  }`,
                }]
        }], propDecorators: { picker: [{
                type: Input,
                args: [{ required: true }]
            }] } });
export class ThemePicker {
    constructor() {
        this.roles = allRoles;
        this.view = 'shared-wheel';
        this.custom = false;
        this.state = signal(null);
        this.allRoles = allRoles;
        this.views = themePickerViews;
        this.theme = useThemeStore();
        this.destroy = inject(DestroyRef);
        let cleanup;
        afterNextRender(() => {
            cleanup = this.picker.mount();
        });
        this.destroy.onDestroy(() => cleanup?.());
        afterRenderEffect(() => {
            const view = this.state()?.view;
            if (this.viewSelect && view)
                this.viewSelect.nativeElement.value = view;
        });
    }
    ngOnInit() {
        this.picker =
            this.store ??
                createThemePickerStore(this.theme, {
                    disabled: this.disabled,
                    roles: this.roles,
                    activeRole: this.activeRole,
                    view: this.view,
                });
        this.state.set(this.picker.getSnapshot());
        this.destroy.onDestroy(this.picker.subscribe(() => this.state.set(this.picker.getSnapshot())));
    }
    changeView(event) {
        this.picker.setView(event.target.value);
    }
    toggle(role, event) {
        const current = this.picker.getSnapshot().roles;
        this.picker.setRoles(event.target.checked
            ? [...current, role]
            : current.filter((r) => r !== role));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemePicker, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ThemePicker, isStandalone: true, selector: "tk-picker", inputs: { disabled: "disabled", controls: "controls", roles: "roles", activeRole: "activeRole", view: "view", store: "store", custom: "custom" }, viewQueries: [{ propertyName: "viewSelect", first: true, predicate: ["viewSelect"], descendants: true }], ngImport: i0, template: `@if (state(); as s) {
    <cp-provider [store]="picker.activeColor"
      ><div class="tk-picker tk-generator">
        <label
          class="cp-format"
          [hidden]="
            controls === false || (controls === undefined && roles.length === 1)
          "
          >Theme picker view<select #viewSelect (change)="changeView($event)">
            @for (view of views; track view) {
              <option
                [value]="view"
                [attr.selected]="s.view === view ? '' : null"
              >
                {{
                  view === 'area'
                    ? 'Rectangle'
                    : view === 'wheel'
                      ? 'Wheel'
                      : 'Shared wheel'
                }}
              </option>
            }
          </select></label
        >
        <fieldset
          class="tk-role-options"
          [hidden]="
            controls === false || (controls === undefined && roles.length === 1)
          "
        >
          <legend>Visible roles</legend>
          @for (role of allRoles; track role) {
            <label
              ><input
                type="checkbox"
                [checked]="s.roles.includes(role)"
                [disabled]="s.roles.length === 1 && s.roles.includes(role)"
                (change)="toggle(role, $event)"
              />{{ role }}</label
            >
          }
        </fieldset>
        <div
          class="tk-role-tabs"
          aria-label="Active color"
          [hidden]="s.roles.length === 1"
        >
          @for (role of s.roles; track role) {
            <button
              type="button"
              [attr.aria-pressed]="s.activeRole === role"
              (click)="picker.selectRole(role)"
            >
              <span [style.background]="s.colors[role].hex"></span>{{ role }}
            </button>
          }
        </div>
        @if (s.view === 'shared-wheel') {
          <tk-wheel [picker]="picker" />
        } @else if (s.view === 'wheel') {
          <cp-wheel />
        } @else {
          <cp-area />
        }
        <p class="tk-editing" aria-live="polite">Editing {{ s.activeRole }}</p>
        @if (custom) {
          <ng-content />
        } @else {
          <cp-slider
            [channel]="s.view === 'area' ? 'h' : 'v'"
          /><cp-format-select /><cp-input /><cp-mode />
        }</div
    ></cp-provider>
  }`, isInline: true, dependencies: [{ kind: "component", type: ColorProvider, selector: "cp-provider", inputs: ["value", "disabled", "view", "store"], outputs: ["colorChange"] }, { kind: "component", type: ColorArea, selector: "cp-area", inputs: ["classes", "className", "thumbText", "label"] }, { kind: "component", type: ColorWheel, selector: "cp-wheel", inputs: ["label", "className", "classes", "thumbText", "markers", "activeId"], outputs: ["markerSelect", "markerChange"] }, { kind: "component", type: ColorSlider, selector: "cp-slider", inputs: ["channel", "classes", "className", "label"] }, { kind: "component", type: ColorFormatSelect, selector: "cp-format-select", inputs: ["label"] }, { kind: "component", type: ColorInput, selector: "cp-input", inputs: ["classes", "className", "format", "label"] }, { kind: "component", type: ColorMode, selector: "cp-mode" }, { kind: "component", type: ThemeWheel, selector: "tk-wheel", inputs: ["picker"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemePicker, decorators: [{
            type: Component,
            args: [{
                    selector: 'tk-picker',
                    standalone: true,
                    imports: [
                        ColorProvider,
                        ColorArea,
                        ColorWheel,
                        ColorSlider,
                        ColorFormatSelect,
                        ColorInput,
                        ColorMode,
                        ThemeWheel,
                    ],
                    template: `@if (state(); as s) {
    <cp-provider [store]="picker.activeColor"
      ><div class="tk-picker tk-generator">
        <label
          class="cp-format"
          [hidden]="
            controls === false || (controls === undefined && roles.length === 1)
          "
          >Theme picker view<select #viewSelect (change)="changeView($event)">
            @for (view of views; track view) {
              <option
                [value]="view"
                [attr.selected]="s.view === view ? '' : null"
              >
                {{
                  view === 'area'
                    ? 'Rectangle'
                    : view === 'wheel'
                      ? 'Wheel'
                      : 'Shared wheel'
                }}
              </option>
            }
          </select></label
        >
        <fieldset
          class="tk-role-options"
          [hidden]="
            controls === false || (controls === undefined && roles.length === 1)
          "
        >
          <legend>Visible roles</legend>
          @for (role of allRoles; track role) {
            <label
              ><input
                type="checkbox"
                [checked]="s.roles.includes(role)"
                [disabled]="s.roles.length === 1 && s.roles.includes(role)"
                (change)="toggle(role, $event)"
              />{{ role }}</label
            >
          }
        </fieldset>
        <div
          class="tk-role-tabs"
          aria-label="Active color"
          [hidden]="s.roles.length === 1"
        >
          @for (role of s.roles; track role) {
            <button
              type="button"
              [attr.aria-pressed]="s.activeRole === role"
              (click)="picker.selectRole(role)"
            >
              <span [style.background]="s.colors[role].hex"></span>{{ role }}
            </button>
          }
        </div>
        @if (s.view === 'shared-wheel') {
          <tk-wheel [picker]="picker" />
        } @else if (s.view === 'wheel') {
          <cp-wheel />
        } @else {
          <cp-area />
        }
        <p class="tk-editing" aria-live="polite">Editing {{ s.activeRole }}</p>
        @if (custom) {
          <ng-content />
        } @else {
          <cp-slider
            [channel]="s.view === 'area' ? 'h' : 'v'"
          /><cp-format-select /><cp-input /><cp-mode />
        }</div
    ></cp-provider>
  }`,
                }]
        }], ctorParameters: () => [], propDecorators: { disabled: [{
                type: Input
            }], controls: [{
                type: Input
            }], roles: [{
                type: Input
            }], activeRole: [{
                type: Input
            }], view: [{
                type: Input
            }], store: [{
                type: Input
            }], custom: [{
                type: Input
            }], viewSelect: [{
                type: ViewChild,
                args: ['viewSelect']
            }] } });
export class ThemeSelect {
    list() {
        return themeList(this.themes);
    }
    value() {
        return selectedThemeId(this.state().theme, this.list()) ?? '';
    }
    choose(event) {
        const theme = this.list().find((theme) => theme.id === event.target.value);
        if (theme)
            this.store.setTheme(theme);
    }
    constructor() {
        this.themes = [];
        this.label = 'Saved themes';
        this.store = useThemeStore();
        this.state = useTheme();
        afterRenderEffect(() => {
            this.select.nativeElement.value = this.value();
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeSelect, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ThemeSelect, isStandalone: true, selector: "tk-select", inputs: { themes: "themes", label: "label" }, viewQueries: [{ propertyName: "select", first: true, predicate: ["select"], descendants: true }], ngImport: i0, template: `<label class="cp-format tk-select"
    >{{ label
    }}<select #select [disabled]="!themes.length" (change)="choose($event)">
      <option value="" disabled [attr.selected]="!value() ? '' : null">
        {{ themes.length ? 'Custom theme' : 'No themes available' }}
      </option>
      @for (theme of list(); track theme.id) {
        <option
          [value]="theme.id"
          [attr.selected]="value() === theme.id ? '' : null"
        >
          {{ theme.name }}
        </option>
      }
    </select></label
  >`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeSelect, decorators: [{
            type: Component,
            args: [{
                    selector: 'tk-select',
                    standalone: true,
                    template: `<label class="cp-format tk-select"
    >{{ label
    }}<select #select [disabled]="!themes.length" (change)="choose($event)">
      <option value="" disabled [attr.selected]="!value() ? '' : null">
        {{ themes.length ? 'Custom theme' : 'No themes available' }}
      </option>
      @for (theme of list(); track theme.id) {
        <option
          [value]="theme.id"
          [attr.selected]="value() === theme.id ? '' : null"
        >
          {{ theme.name }}
        </option>
      }
    </select></label
  >`,
                }]
        }], ctorParameters: () => [], propDecorators: { themes: [{
                type: Input
            }], label: [{
                type: Input
            }], select: [{
                type: ViewChild,
                args: ['select']
            }] } });
export class ThemeExport {
    set selection(value) {
        this.selectionKey.set(JSON.stringify(value));
    }
    get selection() {
        const key = this.selectionKey();
        return key ? JSON.parse(key) : undefined;
    }
    configuration() {
        return themeConfiguration(this.state(), this.selection);
    }
    constructor() {
        this.format = 'json';
        this.selectionKey = signal(undefined);
        this.custom = false;
        this.configurationChange = new EventEmitter();
        this.state = useTheme();
        afterRenderEffect(() => {
            this.configurationChange.emit(this.configuration());
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeExport, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.25", type: ThemeExport, isStandalone: true, selector: "tk-export", inputs: { format: "format", selection: "selection", custom: "custom" }, outputs: { configurationChange: "configurationChange" }, ngImport: i0, template: `@if (custom) {
      <ng-content />
    } @else {
      <pre class="tk-export" aria-label="Theme configuration">{{
        configuration()[format]
      }}</pre>
    }`, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.25", ngImport: i0, type: ThemeExport, decorators: [{
            type: Component,
            args: [{
                    selector: 'tk-export',
                    standalone: true,
                    template: `@if (custom) {
      <ng-content />
    } @else {
      <pre class="tk-export" aria-label="Theme configuration">{{
        configuration()[format]
      }}</pre>
    }`,
                }]
        }], ctorParameters: () => [], propDecorators: { format: [{
                type: Input
            }], selection: [{
                type: Input
            }], custom: [{
                type: Input
            }], configurationChange: [{
                type: Output
            }] } });
