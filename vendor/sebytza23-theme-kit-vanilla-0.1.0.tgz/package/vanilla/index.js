// packages/theme-kit/vanilla/elements.ts
import "@sebytza23/color-picker-vanilla";

// packages/theme-kit/vanilla/style.ts
function scopeStyle(state) {
  return `${state.style};--tk-loading-display:${state.status === "loading" ? "contents" : "none"};--tk-ready-display:${state.status === "loading" ? "none" : "contents"};--tk-error-display:${state.error ? "contents" : "none"}`;
}

// packages/theme-kit/vanilla/elements.ts
import { channelsToHex } from "@sebytza23/color-picker";
import {
  browserModeStorage,
  nextThemeMode,
  isModePreference,
  suggestedThemeName,
  themeList,
  selectedThemeId,
  themeConfiguration,
  createHttpThemeLoader,
  themePickerMarkers,
  createThemePickerStore,
  createThemeStore,
  mountThemeStore,
  browserStorage,
  shades
} from '@sebytza23/theme-kit';
var ThemeProviderElement = class extends HTMLElement {
  setStore(store, options) {
    if (options) this.options = options;
    this.cleanup?.();
    this.cleanup = void 0;
    this.store = store;
    if (this.isConnected) this.connectedCallback();
  }
  connectedCallback() {
    if (this.cleanup) return;
    const { src, storageKey, modeStorageKey, ...serialized } = JSON.parse(
      this.getAttribute("data-config") ?? "{}"
    );
    const options = { ...serialized, ...this.options };
    if (src) options.loadTheme = createHttpThemeLoader(src);
    if (storageKey) options.storage = browserStorage(storageKey);
    if (modeStorageKey && options.modeStorage !== false) options.modeStorage = browserModeStorage(modeStorageKey);
    this.store ??= createThemeStore(options);
    const store = this.store;
    const update = () => {
      const state = store.getSnapshot();
      this.style.cssText = scopeStyle(state);
      this.dataset.theme = state.theme.id;
      this.dataset.mode = state.mode;
      this.dataset.modePreference = state.modePreference;
      this.querySelectorAll("[data-tk-mode]").forEach((button) => {
        if (button.closest("tk-provider") !== this) return;
        const value = button.dataset.tkMode;
        if (isModePreference(value)) button.setAttribute("aria-pressed", String(value === state.modePreference));
        const label = button.querySelector("[data-mode-label]");
        if (label) label.textContent = JSON.parse(button.dataset.modeLabels ?? "{}")[value || state.modePreference];
      });
      this.querySelectorAll("[data-tk-name]").forEach((input) => {
        if (input.closest("tk-provider") !== this) return;
        if (input.ownerDocument.activeElement !== input) input.value = state.theme.name;
        input.placeholder = suggestedThemeName(state.theme);
      });
      this.querySelectorAll("[data-tk-name-suggestion]").forEach((element) => {
        if (element.closest("tk-provider") === this) element.textContent = `Suggested: ${suggestedThemeName(state.theme)}`;
      });
      this.dataset.themeStatus = state.status;
      for (const provider of this.querySelectorAll(
        "cp-provider[data-theme-generator]"
      ))
        if (provider.closest("tk-provider") === this)
          provider.store?.setHex(
            channelsToHex(
              state.theme.structure.userPreset[provider.dataset.role ?? "primary"].DEFAULT
            )
          );
      this.querySelectorAll("[data-tk-background]").forEach(
        (input) => {
          if (input.closest("tk-provider") === this)
            input.checked = state.background === "tinted";
        }
      );
      this.querySelectorAll("[data-tk-harmony]").forEach(
        (input) => {
          if (input.closest("tk-provider") === this)
            input.value = state.theme.harmony ?? "analogous";
        }
      );
      this.querySelectorAll("[data-tk-border]").forEach(
        (input) => {
          if (input.closest("tk-provider") === this)
            input.value = String(
              state.theme.structure.websitePreset.border[input.dataset.tkBorder][input.dataset.target]
            );
        }
      );
      this.dispatchEvent(new CustomEvent("theme-change", { detail: state }));
    };
    const color = (event) => {
      const target = event.target;
      if (target.matches("cp-provider[data-theme-generator]") && target.closest("tk-provider") === this) {
        const hex = event.detail;
        if (hex !== channelsToHex(
          store.getSnapshot().theme.structure.userPreset[target.dataset.role ?? "primary"].DEFAULT
        ))
          store.setColor(target.dataset.role ?? "primary", hex);
      }
    };
    const click = (event) => {
      const button = event.target.closest(
        "[data-tk-mode],[data-tk-retry],[data-tk-theme],[data-tk-generate-harmony]"
      );
      if (button?.closest("tk-provider") !== this) return;
      if (button.hasAttribute("data-tk-mode"))
        store.setMode(isModePreference(button.dataset.tkMode) ? button.dataset.tkMode : nextThemeMode(store.getSnapshot().modePreference));
      else if (button.hasAttribute("data-tk-retry")) void store.reload();
      else if (button.hasAttribute("data-tk-generate-harmony"))
        store.generateHarmony();
      else store.setTheme(JSON.parse(button.getAttribute("data-tk-theme")));
    };
    const background = (event) => {
      const input = event.target;
      if (input.matches("[data-tk-background]") && input.closest("tk-provider") === this)
        store.setBackground(input.checked ? "tinted" : "neutral");
    };
    const edit = (event) => {
      const input = event.target;
      if (input.closest("tk-provider") !== this) return;
      if (input.matches("[data-tk-name]")) store.setName(event.type === "change" && !input.value ? void 0 : input.value);
      if (input.matches("[data-tk-harmony]"))
        store.setHarmony(input.value);
      if (input.matches("[data-tk-border]")) {
        const n = input.valueAsNumber;
        if (Number.isFinite(n) && n >= 0 && n <= 1e3)
          store.setBorder(
            input.dataset.tkBorder,
            input.dataset.target,
            n
          );
      }
    };
    this.addEventListener("change", edit);
    this.addEventListener("input", edit);
    this.addEventListener("change", background);
    this.addEventListener("color-change", color);
    this.addEventListener("click", click);
    update();
    const unsubscribe = store.subscribe(update), unmount = mountThemeStore(store, options.storage, options);
    this.cleanup = () => {
      unsubscribe();
      unmount();
      this.removeEventListener("change", edit);
      this.removeEventListener("input", edit);
      this.removeEventListener("change", background);
      this.removeEventListener("color-change", color);
      this.removeEventListener("click", click);
    };
  }
  disconnectedCallback() {
    this.cleanup?.();
    this.cleanup = void 0;
  }
};
var ThemePaletteElement = class extends HTMLElement {
  connectedCallback() {
    const root = this.closest("tk-provider");
    if (!root) return;
    const update = () => {
      if (!root.store) return;
      const role = this.getAttribute("role-name") ?? "primary";
      const palette = root.store.getSnapshot().theme.structure.userPreset[role];
      this.querySelectorAll("[data-shade]").forEach(
        (element, i) => {
          element.style.background = `hsl(${palette[shades[i]]})`;
        }
      );
    };
    root.addEventListener("theme-change", update);
    update();
    this.cleanup = () => root.removeEventListener("theme-change", update);
  }
  disconnectedCallback() {
    this.cleanup?.();
  }
};
if (!customElements.get("tk-provider"))
  customElements.define("tk-provider", ThemeProviderElement);
if (!customElements.get("tk-palette"))
  customElements.define("tk-palette", ThemePaletteElement);
var ThemePickerElement = class extends HTMLElement {
  connectedCallback() {
    const root = this.closest("tk-provider");
    if (!root) return;
    let boundStore;
    const setup = () => {
      if (!this.isConnected || !root.store || this.cleanup && boundStore === root.store) return;
      const provider = this.querySelector("cp-provider[data-tk-active-color]");
      const wheel = this.querySelector('[data-picker-surface="shared-wheel"] cp-wheel');
      if (!provider || !wheel) return;
      customElements.upgrade(this);
      this.cleanup?.();
      this.cleanup = void 0;
      boundStore = root.store;
      const picker = createThemePickerStore(
        root.store,
        JSON.parse(this.getAttribute("data-options") ?? "{}")
      );
      provider.setStore(picker.activeColor);
      const update = () => {
        const state = picker.getSnapshot();
        this.querySelector("[data-picker-view]").value = state.view;
        this.querySelectorAll("[data-picker-surface]").forEach(
          (el) => el.hidden = el.dataset.pickerSurface !== state.view
        );
        this.querySelectorAll("[data-picker-channel]").forEach(
          (el) => el.hidden = el.dataset.pickerChannel !== (state.view === "area" ? "h" : "v")
        );
        this.querySelector(".tk-editing").textContent = `Editing ${state.activeRole}`;
        this.querySelectorAll("[data-include-role]").forEach(
          (input) => {
            const role = input.dataset.includeRole;
            input.checked = state.roles.includes(role);
            input.disabled = state.roles.length === 1 && input.checked;
          }
        );
        this.querySelectorAll("[data-select-role]").forEach(
          (button) => {
            const role = button.dataset.selectRole;
            button.hidden = !state.roles.includes(role);
            button.setAttribute(
              "aria-pressed",
              String(state.activeRole === role)
            );
            button.firstElementChild.style.background = state.colors[role].hex;
          }
        );
        wheel.setMarkers(themePickerMarkers(state), state.activeRole);
      };
      const change = (event) => {
        const input = event.target;
        if (input.matches("[data-picker-view]"))
          picker.setView(input.value);
        if (input.matches("[data-include-role]")) {
          const role = input.dataset.includeRole, current = picker.getSnapshot().roles;
          picker.setRoles(
            input.checked ? [...current, role] : current.filter((r) => r !== role)
          );
        }
      };
      const click = (event) => {
        const button = event.target.closest(
          "[data-select-role]"
        );
        if (button) picker.selectRole(button.dataset.selectRole);
      };
      const markerSelect = (e) => picker.selectRole(e.detail);
      const markerChange = (e) => {
        const { id, hsv } = e.detail;
        picker.setHSV(id, hsv);
      };
      wheel.addEventListener("marker-select", markerSelect);
      wheel.addEventListener("marker-change", markerChange);
      this.addEventListener("change", change);
      this.addEventListener("click", click);
      const unsubscribe = picker.subscribe(update), unmount = picker.mount();
      update();
      this.cleanup = () => {
        unsubscribe();
        unmount();
        wheel.removeEventListener("marker-select", markerSelect);
        wheel.removeEventListener("marker-change", markerChange);
        this.removeEventListener("change", change);
        this.removeEventListener("click", click);
      };
    };
    root.addEventListener("theme-change", setup);
    this.ownerDocument.addEventListener("DOMContentLoaded", setup, { once: true });
    this.detach = () => {
      root.removeEventListener("theme-change", setup);
      this.ownerDocument.removeEventListener("DOMContentLoaded", setup);
    };
    setup();
    queueMicrotask(setup);
  }
  disconnectedCallback() {
    this.detach?.();
    this.detach = void 0;
    this.cleanup?.();
    this.cleanup = void 0;
  }
};
if (!customElements.get("tk-picker"))
  customElements.define("tk-picker", ThemePickerElement);
function connectTheme(element, render) {
  const root = element.closest("tk-provider");
  if (!root) throw new Error("Theme components require tk-provider");
  const update = () => {
    if (root.store) render(root.store);
  };
  root.addEventListener("theme-change", update);
  update();
  return () => root.removeEventListener("theme-change", update);
}
var ThemeSelectElement = class extends HTMLElement {
  connectedCallback() {
    const themes = themeList(JSON.parse(this.dataset.themes ?? "[]")), select = this.querySelector("select");
    const choose = () => {
      const theme = themes.find((theme2) => theme2.id === select.value), root = this.closest("tk-provider");
      if (theme) root?.store?.setTheme(theme);
    };
    select.addEventListener("change", choose);
    const disconnect = connectTheme(this, (store) => {
      select.value = selectedThemeId(store.getSnapshot().theme, themes) ?? "";
    });
    this.cleanup = () => {
      disconnect();
      select.removeEventListener("change", choose);
    };
  }
  disconnectedCallback() {
    this.cleanup?.();
    this.cleanup = void 0;
  }
};
var ThemeExportElement = class extends HTMLElement {
  connectedCallback() {
    this.cleanup = connectTheme(this, (store) => {
      const state = store.getSnapshot(), selection = this.dataset.selection ? JSON.parse(this.dataset.selection) : void 0;
      const next = themeConfiguration(state, selection);
      if (this.configuration?.theme === next.theme && this.configuration.mode === next.mode && this.configuration.modePreference === next.modePreference && this.configuration.systemMode === next.systemMode)
        return;
      this.configuration = next;
      const pre = this.querySelector("pre");
      if (pre)
        pre.textContent = next[this.getAttribute("format") ?? "json"];
      this.dispatchEvent(
        new CustomEvent("configuration-change", {
          detail: next,
          bubbles: true
        })
      );
    });
  }
  disconnectedCallback() {
    this.cleanup?.();
    this.cleanup = void 0;
    this.configuration = void 0;
  }
};
if (!customElements.get("tk-select"))
  customElements.define("tk-select", ThemeSelectElement);
if (!customElements.get("tk-export"))
  customElements.define("tk-export", ThemeExportElement);

// packages/theme-kit/vanilla/index.ts
export * from '@sebytza23/theme-kit';
import { colorAreaMarkup, colorWheelMarkup, colorFormatMarkup, colorSliderMarkup } from "@sebytza23/color-picker-vanilla";
import { createThemeStore as createThemeStore2, themeConfiguration as themeConfiguration2 } from '@sebytza23/theme-kit';
var roles = ["primary", "secondary", "accent"];
var themePickerMarkup = `<tk-picker><cp-provider data-tk-active-color><div class="tk-picker tk-generator">
  <label class="cp-format">Theme picker view<select data-picker-view><option value="area">Rectangle</option><option value="wheel">Wheel</option><option value="shared-wheel">Shared wheel</option></select></label>
  <fieldset class="tk-role-options"><legend>Visible roles</legend>${roles.map((role) => `<label><input type="checkbox" data-include-role="${role}" checked />${role}</label>`).join("")}</fieldset>
  <div class="tk-role-tabs" aria-label="Active color">${roles.map((role) => `<button type="button" data-select-role="${role}"><span></span>${role}</button>`).join("")}</div>
  <div data-picker-surface="shared-wheel"><cp-wheel data-markers="[]"><div class="cp-wheel tk-shared-wheel" data-area data-cp-part="surface" role="group" tabindex="0" aria-label="Shared theme color wheel"></div></cp-wheel></div>
  <div data-picker-surface="area">${colorAreaMarkup}</div><div data-picker-surface="wheel">${colorWheelMarkup}</div>
  <p class="tk-editing" aria-live="polite"></p>
  <div data-picker-channel="h">${colorSliderMarkup("h", "Hue")}</div><div data-picker-channel="v">${colorSliderMarkup("v", "Brightness")}</div>
  ${colorFormatMarkup}<cp-input></cp-input><cp-mode><button type="button">Switch format</button></cp-mode>
</div></cp-provider></tk-picker>`;
var themeKitMarkup = `<div class="tk-generator">
  <div class="tk-role-tabs" aria-label="Theme mode"><button type="button" data-tk-mode="system">System</button><button type="button" data-tk-mode="light">Light mode</button><button type="button" data-tk-mode="dark">Dark mode</button></div>
  <label class="tk-name">Theme name<input data-tk-name maxlength="200" /><small data-tk-name-suggestion></small></label>
  <tk-select><label class="cp-format">Saved themes<select><option value="" disabled>Custom theme</option></select></label></tk-select>
  ${themePickerMarkup}
  <div class="tk-harmony"><label>Color harmony<select data-tk-harmony><option value="analogous">Analogous</option><option value="triadic">Triadic</option><option value="split-complementary">Split complementary</option></select></label><button type="button" data-tk-generate-harmony>Generate accent &amp; secondary</button></div>
  <label class="tk-background"><input type="checkbox" data-tk-background />Tint background with primary</label>
  <label class="tk-border">Card radius<input type="number" min="0" max="1000" step=".125" data-tk-border="radius" data-target="card" />rem</label>
  <label class="tk-border">Card border width<input type="number" min="0" max="1000" step="1" data-tk-border="width" data-target="card" />px</label>
  <details><summary>Export configuration</summary><tk-export format="json"><pre class="tk-export" aria-label="Theme configuration"></pre></tk-export></details>
</div>`;
function mountThemeKit(host, options = {}) {
  const store = options.store ?? createThemeStore2(options), provider = host.ownerDocument.createElement("tk-provider");
  provider.className = `tk-scope ${options.className ?? ""}`;
  provider.setStore(store, options);
  provider.innerHTML = themeKitMarkup;
  const picker = provider.querySelector("tk-picker");
  picker.setAttribute("data-options", JSON.stringify(options.picker ?? {}));
  const list = provider.querySelector("tk-select");
  list.setAttribute("data-themes", JSON.stringify(options.themes ?? []));
  const select = list.querySelector("select");
  select.disabled = !options.themes?.length;
  for (const theme of options.themes ?? []) {
    const option = host.ownerDocument.createElement("option");
    option.value = theme.id;
    option.textContent = theme.name;
    select.append(option);
  }
  const change = () => options.onChange?.(themeConfiguration2(store.getSnapshot()));
  provider.addEventListener("theme-change", change);
  host.append(provider);
  return {
    element: provider,
    store,
    getConfiguration: () => themeConfiguration2(store.getSnapshot()),
    destroy() {
      provider.removeEventListener("theme-change", change);
      provider.remove();
    }
  };
}
export {
  ThemeExportElement,
  ThemeProviderElement,
  ThemeSelectElement,
  mountThemeKit,
  themeKitMarkup,
  themePickerMarkup
};
//# sourceMappingURL=index.js.map
