import type { ThemeSnapshot } from '@sebytza23/theme-kit';
export declare function scopeStyle(state: ThemeSnapshot): string;
