export * from './elements.js';
export * from '@sebytza23/theme-kit';
import { type ThemeOptions, type ThemeStore, type Theme, type ThemePickerOptions, type ThemeConfiguration } from '@sebytza23/theme-kit';
import type { ThemeProviderElement } from './elements.js';
export interface ThemeKitOptions extends ThemeOptions {
    store?: ThemeStore;
    themes?: readonly Theme[];
    picker?: ThemePickerOptions;
    className?: string;
    onChange?: (configuration: ThemeConfiguration) => void;
}
export declare const themePickerMarkup: string;
export declare const themeKitMarkup: string;
/** Fully native DOM controls; PHP/htmx can instead emit any subset of these HTML parts. */
export declare function mountThemeKit(host: HTMLElement, options?: ThemeKitOptions): {
    element: ThemeProviderElement;
    store: ThemeStore;
    getConfiguration: () => ThemeConfiguration;
    destroy(): void;
};
