export * from './elements.js';
export * from '@sebytza23/theme-kit';
import { type ThemeOptions, type ThemeStore, type Theme, type ThemePickerOptions, type ThemeConfiguration, type TokenSelection, type Target, type Role, type PaletteOptions } from '@sebytza23/theme-kit';
import type { ThemeProviderElement } from './elements.js';
export interface ThemeKitOptions extends ThemeOptions {
    store?: ThemeStore;
    themes?: readonly Theme[];
    picker?: ThemePickerOptions;
    radius?: readonly Target[];
    width?: readonly Target[];
    backgroundControl?: boolean;
    className?: string;
    onChange?: (configuration: ThemeConfiguration) => void;
}
export declare const themePickerMarkup: string;
export declare const themeKitMarkup: string;
/** Native DOM controls with exports limited to the mounted fields. */
export declare function mountThemeKit(host: HTMLElement, options?: ThemeKitOptions): {
    element: ThemeProviderElement;
    store: ThemeStore;
    getConfiguration: (selection?: TokenSelection) => ThemeConfiguration;
    destroy(): void;
};
/** Shade colors come from the nearest theme provider. All other parts can be styled. */
export declare function themePaletteMarkup(role?: Role, options?: PaletteOptions): string;
