import '@sebytza23/color-picker-vanilla';
import { type ThemeConfiguration, type ThemeOptions, type ThemeStore } from '@sebytza23/theme-kit';
export declare class ThemeProviderElement extends HTMLElement {
    store?: ThemeStore;
    options?: ThemeOptions;
    private cleanup?;
    setStore(store: ThemeStore, options?: ThemeOptions): void;
    connectedCallback(): void;
    disconnectedCallback(): void;
}
export declare class ThemeSelectElement extends HTMLElement {
    private cleanup?;
    connectedCallback(): void;
    disconnectedCallback(): void;
}
export declare class ThemeExportElement extends HTMLElement {
    configuration?: ThemeConfiguration;
    private cleanup?;
    connectedCallback(): void;
    disconnectedCallback(): void;
}
