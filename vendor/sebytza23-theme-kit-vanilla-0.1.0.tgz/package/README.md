# @sebytza23/theme-kit-vanilla

Install only this adapter and its core dependencies.

`npm install @sebytza23/theme-kit-vanilla`

Documentation: https://sebytza23.github.io/theme-kit/docs.html

Browser scripts are in browser/ for vanilla HTML and PHP; no framework is required.
