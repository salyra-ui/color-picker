// packages/theme-kit/core/types.ts
var shades = [
  50,
  100,
  200,
  300,
  400,
  500,
  600,
  700,
  800,
  900,
  950
];
var roles = ["primary", "secondary", "accent"];
var harmonies = [
  "analogous",
  "triadic",
  "split-complementary"
];
var targets = [
  "DEFAULT",
  "input",
  "card",
  "popover",
  "button",
  "table",
  "picker"
];
var modePreferences = ["system", "light", "dark"];

// packages/theme-kit/core/theme.ts
import {
  hexToOklch,
  oklchToHex,
  channelsToHex,
  foreground,
  hexToHsv,
  hsvToChannels,
  normalizeHex,
  hue,
  getColorName
} from "@sebytza23/color-picker";
function generatePalette(seed) {
  const hsv = hexToHsv(seed);
  const result = {};
  const light = [0.95, 0.9, 0.75, 0.6, 0.3], dark = [0.1, 0.25, 0.4, 0.55, 0.71];
  for (const [i, shade] of shades.entries()) {
    const amount = i < 5 ? light[i] : i > 5 ? dark[i - 6] : 0;
    result[shade] = hsvToChannels(
      i < 5 ? {
        h: hsv.h,
        s: hsv.s * (1 - amount),
        v: hsv.v + (100 - hsv.v) * amount
      } : { h: hsv.h, s: hsv.s, v: hsv.v * (1 - amount) }
    );
  }
  result.DEFAULT = result[500];
  result.foreground = foreground(seed);
  return Object.freeze(result);
}
function generateTheme(seed, options = {}) {
  seed = normalizeHex(seed);
  const harmony = options.harmony ?? options.base?.harmony ?? "analogous";
  if (!harmonies.includes(harmony)) throw new TypeError("Invalid harmony");
  const selected = options.roles ?? roles;
  if (selected.some((role) => !roles.includes(role)))
    throw new TypeError("Invalid role");
  const colors = harmonyColors(seed, harmony);
  const userPreset = Object.fromEntries(
    roles.map((role) => [
      role,
      options.base && !selected.includes(role) ? options.base.structure.userPreset[role] : generatePalette(colors[role])
    ])
  );
  let websitePreset = options.base?.structure.websitePreset ?? {
    foreground: { light: "0 0% 10%", dark: "0 0% 98%" },
    background: { light: "0 0% 100%", dark: "0 0% 8%" },
    border: {
      width: Object.fromEntries(targets.map((t) => [t, 1])),
      radius: Object.fromEntries(targets.map((t) => [t, 0.5]))
    }
  };
  const backgroundMode = options.background ?? options.base?.backgroundMode ?? (options.base ? "preserve" : "neutral");
  if (backgroundMode !== "preserve" && (!options.base || selected.includes("primary")))
    websitePreset = {
      ...websitePreset,
      ...generateBackground(seed, backgroundMode)
    };
  return parseTheme({
    backgroundMode,
    harmony,
    id: options.id ?? `custom-${seed.slice(1).toLowerCase()}`,
    name: options.name ?? (options.base?.nameSource === "custom" ? options.base.name : getColorName(seed)),
    nameSource: options.name !== void 0 || options.base?.nameSource === "custom" ? "custom" : "suggested",
    structure: { userPreset, websitePreset }
  });
}
var object = (v) => {
  if (!v || typeof v !== "object" || Array.isArray(v))
    throw new TypeError("Expected theme object");
  return v;
};
function channels(v) {
  if (typeof v !== "string" || !/^\d+(?:\.\d+)? \d+(?:\.\d+)?% \d+(?:\.\d+)?%$/.test(v))
    throw new TypeError("Invalid HSL channels");
  const [h, s, l] = v.replace(/%/g, "").split(" ").map(Number);
  if (h > 360 || s > 100 || l > 100)
    throw new TypeError("HSL channel out of range");
  return v;
}
function parseTheme(value) {
  const t = object(value);
  if (typeof t.id !== "string" || !t.id.length || t.id.length > 128 || typeof t.name !== "string" || t.name.length > 200)
    throw new TypeError("Invalid theme identity");
  if (t.backgroundMode !== void 0 && !["neutral", "tinted", "preserve"].includes(String(t.backgroundMode)))
    throw new TypeError("Invalid background mode");
  if (t.harmony !== void 0 && !harmonies.includes(t.harmony))
    throw new TypeError("Invalid harmony");
  if (t.nameSource !== void 0 && !["suggested", "custom"].includes(String(t.nameSource)))
    throw new TypeError("Invalid theme name source");
  const structure = object(t.structure), user = object(structure.userPreset), web = object(structure.websitePreset), border = object(web.border);
  const userPreset = Object.fromEntries(
    roles.map((role) => {
      const p = object(user[role]);
      return [
        role,
        Object.freeze(
          Object.fromEntries(
            [...shades, "DEFAULT", "foreground"].map((key) => [
              key,
              channels(p[key])
            ])
          )
        )
      ];
    })
  );
  const layers = Object.fromEntries(
    ["foreground", "background"].map((layer) => {
      const p = object(web[layer]);
      return [
        layer,
        Object.freeze({ light: channels(p.light), dark: channels(p.dark) })
      ];
    })
  );
  const borders = Object.fromEntries(
    ["width", "radius"].map((kind) => {
      const p = object(border[kind]);
      return [
        kind,
        Object.freeze(
          Object.fromEntries(
            targets.map((key) => {
              const n = p[key];
              if (typeof n !== "number" || !Number.isFinite(n) || n < 0 || n > 1e3)
                throw new TypeError("Invalid border value");
              return [key, n];
            })
          )
        )
      ];
    })
  );
  return Object.freeze({
    id: t.id,
    name: t.name,
    ...t.nameSource !== void 0 ? { nameSource: t.nameSource } : {},
    ...t.harmony !== void 0 ? { harmony: t.harmony } : {},
    ...t.backgroundMode !== void 0 ? { backgroundMode: t.backgroundMode } : {},
    structure: Object.freeze({
      userPreset: Object.freeze(userPreset),
      websitePreset: Object.freeze({
        ...layers,
        border: Object.freeze(borders)
      })
    })
  });
}
function fromLegacyTheme(value) {
  const t = object(value);
  return parseTheme({
    id: t.ThemeID,
    name: t.Name,
    structure: typeof t.Structure === "string" ? JSON.parse(t.Structure) : t.Structure
  });
}
function toLegacyTheme(theme) {
  return { ThemeID: theme.id, Name: theme.name, Structure: theme.structure };
}
function themeVariables(theme, mode = "light") {
  const result = {};
  for (const role of roles)
    for (const key of [...shades, "DEFAULT", "foreground"])
      result[`--${role}${key === "DEFAULT" ? "" : `-${key}`}`] = theme.structure.userPreset[role][key];
  const p = theme.structure.websitePreset;
  for (const kind of ["width", "radius"])
    for (const target of targets)
      result[`--border-${kind}${target === "DEFAULT" ? "" : `-${target}`}`] = `${p.border[kind][target]}${kind === "width" ? "px" : "rem"}`;
  result["--foreground"] = p.foreground[mode];
  result["--background"] = p.background[mode];
  result["color-scheme"] = mode;
  return result;
}
function themeStyle(theme, mode = "light") {
  return Object.entries(themeVariables(theme, mode)).map(([k, v]) => `${k}:${v}`).join(";");
}
var defaultTheme = generateTheme("#6366F1", {
  id: "default",
  name: "Indigo"
});
function generateBackground(seed, mode) {
  if (mode !== "neutral" && mode !== "tinted")
    throw new TypeError("Invalid background mode");
  if (mode === "neutral")
    return {
      background: { light: "0 0% 100%", dark: "0 0% 8%" },
      foreground: { light: "0 0% 10%", dark: "0 0% 98%" }
    };
  const color = hexToOklch(seed);
  const channels2 = (l, c) => hsvToChannels(hexToHsv(oklchToHex({ l, c, h: color.h })));
  return {
    background: {
      light: channels2(0.985, Math.min(color.c * 0.08, 0.012)),
      dark: channels2(0.145, Math.min(color.c * 0.16, 0.025))
    },
    foreground: { light: "0 0% 10%", dark: "0 0% 98%" }
  };
}
function withThemeBackground(theme, mode) {
  return parseTheme({
    ...theme,
    backgroundMode: mode,
    structure: {
      ...theme.structure,
      websitePreset: {
        ...theme.structure.websitePreset,
        ...generateBackground(
          channelsToHex(theme.structure.userPreset.primary.DEFAULT),
          mode
        )
      }
    }
  });
}
function harmonyColors(seed, harmony = "analogous") {
  if (!harmonies.includes(harmony)) throw new TypeError("Invalid harmony");
  const color = hexToHsv(seed);
  const offsets = {
    analogous: [-30, 30],
    triadic: [120, 240],
    "split-complementary": [150, 210]
  }[harmony];
  const rotate = (offset) => channelsToHex(hsvToChannels({ ...color, h: hue(color.h + offset) }));
  return {
    primary: normalizeHex(seed),
    secondary: rotate(offsets[0]),
    accent: rotate(offsets[1])
  };
}

// packages/theme-kit/core/mode.ts
function isModePreference(value) {
  return typeof value === "string" && modePreferences.includes(value);
}
function nextThemeMode(mode) {
  return modePreferences[(modePreferences.indexOf(mode) + 1) % modePreferences.length];
}
function browserModeStorage(key = "theme-kit:mode") {
  return {
    read: () => localStorage.getItem(key),
    write: (mode) => localStorage.setItem(key, mode),
    subscribe(listener) {
      const update = (event) => {
        if (event.key === key && event.storageArea === localStorage && isModePreference(event.newValue)) listener(event.newValue);
      };
      window.addEventListener("storage", update);
      return () => window.removeEventListener("storage", update);
    }
  };
}
function mountThemeMode(store, storage = browserModeStorage()) {
  if (typeof window === "undefined") return () => {
  };
  try {
    const saved = storage && storage.read();
    if (isModePreference(saved)) store.setMode(saved);
  } catch {
  }
  const query = typeof window.matchMedia === "function" ? window.matchMedia("(prefers-color-scheme: dark)") : void 0;
  const resolve = () => {
    if (query) store.setSystemMode(query.matches ? "dark" : "light");
  };
  resolve();
  query?.addEventListener("change", resolve);
  let last = store.getSnapshot().modePreference, applyingRemote = false;
  const persist = () => {
    const mode = store.getSnapshot().modePreference;
    if (mode === last) return;
    last = mode;
    if (!storage || applyingRemote) return;
    try {
      storage.write(mode);
    } catch {
    }
  };
  const unsubscribe = store.subscribe(persist);
  let unsubscribeStorage;
  try {
    unsubscribeStorage = storage && storage.subscribe?.((value) => {
      if (!isModePreference(value)) return;
      applyingRemote = true;
      try {
        store.setMode(value);
      } finally {
        applyingRemote = false;
      }
    }) || void 0;
  } catch {
  }
  return () => {
    unsubscribe();
    unsubscribeStorage?.();
    query?.removeEventListener("change", resolve);
  };
}
function themeModeActions(store) {
  return {
    setMode: store.setMode,
    cycle: () => store.setMode(nextThemeMode(store.getSnapshot().modePreference))
  };
}

// packages/theme-kit/core/remote.ts
function createHttpThemeLoader(url, options = {}) {
  let cached, etag, revision = 0;
  const load = async (signal) => {
    const version = ++revision, headers = new Headers(options.headers);
    if (etag && cached) headers.set("If-None-Match", etag);
    const response = await (options.fetch ?? fetch)(url, {
      signal,
      headers,
      credentials: options.credentials,
      cache: "no-cache"
    });
    if (signal.aborted) throw new Error("Theme load cancelled");
    if (response.status === 304) {
      if (!cached)
        throw new Error("Theme server returned 304 without a cached theme");
      return cached;
    }
    if (!response.ok)
      throw new Error(`Theme request failed (${response.status})`);
    const theme = parseTheme(await response.json());
    if (signal.aborted) throw new Error("Theme load cancelled");
    if (version === revision) {
      cached = theme;
      etag = response.headers.get("ETag") ?? void 0;
    }
    return theme;
  };
  return Object.assign(load, {
    invalidate() {
      revision++;
      cached = void 0;
      etag = void 0;
    }
  });
}
function watchThemeUpdates(store, options = {}) {
  if (options.intervalMs !== void 0 && (!Number.isFinite(options.intervalMs) || options.intervalMs <= 0))
    throw new TypeError("intervalMs must be positive");
  if (typeof window === "undefined") return () => {
  };
  let disposed = false, running = false, queued = false;
  const refresh = async () => {
    if (disposed) return;
    if (running) {
      queued = true;
      return;
    }
    running = true;
    do {
      queued = false;
      try {
        await store.reload();
      } catch {
      }
    } while (queued && !disposed);
    running = false;
  };
  const focus = () => {
    if (document.visibilityState !== "hidden") void refresh();
  };
  if (options.onFocus ?? true) {
    window.addEventListener("focus", focus);
    document.addEventListener("visibilitychange", focus);
  }
  const timer = options.intervalMs === void 0 ? void 0 : window.setInterval(focus, options.intervalMs);
  const unsubscribe = options.subscribe?.(() => void refresh());
  return () => {
    disposed = true;
    window.removeEventListener("focus", focus);
    document.removeEventListener("visibilitychange", focus);
    window.clearInterval(timer);
    unsubscribe?.();
  };
}

// packages/theme-kit/core/editor.ts
import { channelsToHex as channelsToHex2, getColorName as getColorName2, normalizeHex as normalizeHex2 } from "@sebytza23/color-picker";
function withThemeColor(theme, role, input) {
  if (!roles.includes(role)) throw new TypeError("Invalid role");
  const hex = normalizeHex2(input), primary = role === "primary";
  return parseTheme({
    ...theme,
    ...primary ? {
      id: `custom-${hex.slice(1).toLowerCase()}`,
      name: theme.nameSource === "custom" ? theme.name : getColorName2(hex),
      nameSource: theme.nameSource === "custom" ? "custom" : "suggested"
    } : {},
    structure: {
      userPreset: {
        ...theme.structure.userPreset,
        [role]: generatePalette(hex)
      },
      websitePreset: {
        ...theme.structure.websitePreset,
        ...primary && theme.backgroundMode && theme.backgroundMode !== "preserve" ? generateBackground(hex, theme.backgroundMode) : {}
      }
    }
  });
}
function withThemeBorder(theme, kind, target, value) {
  if (!["width", "radius"].includes(kind) || !targets.includes(target) || !Number.isFinite(value) || value < 0 || value > 1e3)
    throw new TypeError("Invalid border value");
  const web = theme.structure.websitePreset;
  return parseTheme({
    ...theme,
    structure: {
      ...theme.structure,
      websitePreset: {
        ...web,
        border: {
          ...web.border,
          [kind]: { ...web.border[kind], [target]: value }
        }
      }
    }
  });
}
function themeColor(theme, role) {
  if (!roles.includes(role)) throw new TypeError("Invalid role");
  return channelsToHex2(theme.structure.userPreset[role].DEFAULT);
}
function selectThemeTokens(theme, selection = {}) {
  const all = themeVariables(theme, selection.mode), result = {};
  for (const role of selection.roles ?? ["primary"]) {
    if (!roles.includes(role)) throw new TypeError("Invalid role");
    for (const [key, value] of Object.entries(all))
      if (key === `--${role}` || key.startsWith(`--${role}-`))
        result[key] = value;
  }
  for (const kind of ["width", "radius"])
    for (const target of selection[kind] ?? []) {
      if (!targets.includes(target)) throw new TypeError("Invalid target");
      const key = `--border-${kind}${target === "DEFAULT" ? "" : `-${target}`}`;
      result[key] = all[key];
    }
  if (selection.background)
    for (const key of ["--background", "--foreground", "color-scheme"])
      result[key] = all[key];
  return Object.freeze(result);
}
function generateThemeTokens(seed, options = {}) {
  return selectThemeTokens(
    generateTheme(seed, { harmony: options.harmony }),
    options
  );
}
function suggestedThemeName(theme) {
  return getColorName2(themeColor(theme, "primary"));
}
function withThemeName(theme, name) {
  return parseTheme({ ...theme, name: name ?? suggestedThemeName(theme), nameSource: name === void 0 ? "suggested" : "custom" });
}

// packages/theme-kit/core/store.ts
function createThemeStore(options = {}) {
  const fallback = parseTheme(options.fallbackTheme ?? defaultTheme);
  const initialTheme = options.theme ? parseTheme(options.theme) : fallback;
  const theme = options.background ? withThemeBackground(initialTheme, options.background) : initialTheme;
  const waiting = !options.theme && Boolean(options.loadTheme || options.storage);
  const modePreference = options.mode ?? "system";
  if (!isModePreference(modePreference)) throw new TypeError("Invalid mode");
  const systemMode = options.systemMode ?? "light";
  if (systemMode !== "light" && systemMode !== "dark") throw new TypeError("Invalid system mode");
  const mode = modePreference === "system" ? systemMode : modePreference;
  const timeoutMs = options.timeoutMs ?? 1e4;
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0)
    throw new TypeError("timeoutMs must be positive");
  let snapshot = Object.freeze({
    theme,
    background: theme.backgroundMode ?? "preserve",
    mode,
    modePreference,
    systemMode,
    status: waiting ? "loading" : "ready",
    pending: waiting,
    error: null,
    style: themeStyle(theme, mode)
  });
  const serverSnapshot = snapshot;
  const listeners = /* @__PURE__ */ new Set();
  let controller, revision = 0;
  const publish = (patch) => {
    const next = { ...snapshot, ...patch };
    next.background = next.theme.backgroundMode ?? "preserve";
    if (next.theme !== snapshot.theme || next.mode !== snapshot.mode)
      next.style = themeStyle(next.theme, next.mode);
    snapshot = Object.freeze(next);
    listeners.forEach((fn) => fn());
  };
  const cancel = () => {
    revision++;
    controller?.abort();
    controller = void 0;
  };
  async function load(useStorage) {
    cancel();
    const version = revision;
    const request = new AbortController();
    controller = request;
    let timer;
    const current = () => version === revision;
    const interrupted = new Promise((_, reject) => {
      request.signal.addEventListener(
        "abort",
        () => reject(new Error("Theme load cancelled")),
        { once: true }
      );
      timer = setTimeout(
        () => reject(new Error("Theme load timed out")),
        timeoutMs
      );
    });
    publish({ pending: true, error: null });
    try {
      await Promise.race([
        (async () => {
          if (useStorage && options.storage) {
            if (!options.theme) {
              try {
                const value = await options.storage.read();
                if (value != null && current())
                  publish({ theme: parseTheme(value), status: "ready" });
              } catch {
              }
            }
          }
          if (!current()) return;
          if (options.loadTheme) {
            const result = await options.loadTheme(request.signal);
            if (current())
              publish({
                theme: parseTheme(result),
                status: "ready",
                pending: false
              });
          } else if (current()) publish({ status: "ready", pending: false });
        })(),
        interrupted
      ]);
    } catch (error) {
      if (current()) {
        revision++;
        request.abort();
        publish({
          theme: fallback,
          status: "fallback",
          pending: false,
          error: error instanceof Error ? error : new Error(String(error))
        });
      }
    } finally {
      clearTimeout(timer);
      if (current()) controller = void 0;
    }
  }
  const setTheme = (value) => {
    const next = parseTheme(value);
    cancel();
    publish({ theme: next, status: "ready", pending: false, error: null });
  };
  return {
    getSnapshot: () => snapshot,
    getServerSnapshot: () => serverSnapshot,
    subscribe(fn) {
      listeners.add(fn);
      return () => {
        listeners.delete(fn);
      };
    },
    start: () => load(true),
    reload: () => load(false),
    stop() {
      cancel();
    },
    setTheme,
    setMode(mode2) {
      if (!isModePreference(mode2)) throw new TypeError("Invalid mode");
      if (snapshot.modePreference !== mode2) publish({ modePreference: mode2, mode: mode2 === "system" ? snapshot.systemMode : mode2 });
    },
    setSystemMode(mode2) {
      if (mode2 !== "light" && mode2 !== "dark") throw new TypeError("Invalid system mode");
      if (snapshot.systemMode !== mode2) publish({ systemMode: mode2, ...snapshot.modePreference === "system" ? { mode: mode2 } : {} });
    },
    setName(name) {
      setTheme(withThemeName(snapshot.theme, name));
    },
    setBackground(mode2) {
      setTheme(withThemeBackground(snapshot.theme, mode2));
    },
    generate(seed, options2) {
      setTheme(generateTheme(seed, { ...options2, base: snapshot.theme }));
    },
    setColor: (role, hex) => setTheme(withThemeColor(snapshot.theme, role, hex)),
    setBorder: (kind, target, value) => setTheme(withThemeBorder(snapshot.theme, kind, target, value)),
    setHarmony(harmony) {
      if (!harmonies.includes(harmony)) throw new TypeError("Invalid harmony");
      setTheme({ ...snapshot.theme, harmony });
    },
    generateHarmony() {
      const current = snapshot.theme;
      setTheme(
        generateTheme(themeColor(current, "primary"), {
          base: current,
          roles: ["secondary", "accent"],
          id: current.id
        })
      );
    }
  };
}
function mountThemeStore(store, storage, options = {}) {
  let last = store.getSnapshot().theme, timer, queued, applyingRemote = false;
  const write = () => {
    const value = queued;
    queued = void 0;
    if (value && storage)
      try {
        Promise.resolve(storage.write(value)).catch(() => {
        });
      } catch {
      }
  };
  const unsubscribe = store.subscribe(() => {
    const state = store.getSnapshot();
    if (state.theme === last) return;
    last = state.theme;
    if (applyingRemote || state.status !== "ready") return;
    queued = state.theme;
    clearTimeout(timer);
    timer = setTimeout(write, 150);
  });
  const unsubscribeStorage = storage?.subscribe?.((value) => {
    try {
      const remote = parseTheme(value);
      if (JSON.stringify(remote) === JSON.stringify(store.getSnapshot().theme))
        return;
      applyingRemote = true;
      clearTimeout(timer);
      queued = void 0;
      store.setTheme(remote);
    } catch {
    } finally {
      applyingRemote = false;
    }
  });
  const unwatch = options.revalidateOnFocus || options.revalidateIntervalMs !== void 0 ? watchThemeUpdates(store, {
    onFocus: options.revalidateOnFocus ?? false,
    intervalMs: options.revalidateIntervalMs
  }) : () => {
  };
  const unmountMode = mountThemeMode(store, options.modeStorage);
  void store.start();
  return () => {
    unsubscribe();
    unsubscribeStorage?.();
    unwatch();
    unmountMode();
    store.stop();
    clearTimeout(timer);
    write();
  };
}
function browserStorage(key = "@sebytza23/theme-kit") {
  return {
    read() {
      const raw = localStorage.getItem(key);
      if (!raw) return null;
      const data = JSON.parse(raw);
      return data.version === 1 ? data.theme : null;
    },
    subscribe(listener) {
      const update = (event) => {
        if (event.key !== key || event.storageArea !== localStorage || !event.newValue)
          return;
        try {
          const data = JSON.parse(event.newValue);
          if (data.version === 1) listener(data.theme);
        } catch {
        }
      };
      window.addEventListener("storage", update);
      return () => window.removeEventListener("storage", update);
    },
    write(theme) {
      localStorage.setItem(key, JSON.stringify({ version: 1, theme }));
    }
  };
}

// packages/theme-kit/core/picker.ts
import {
  bindMarkerWheel,
  createColorStore,
  wheelStyle
} from "@sebytza23/color-picker";
var themePickerViews = ["area", "wheel", "shared-wheel"];
function createThemePickerStore(theme, options = {}) {
  const validate = (values) => {
    if (!values.length || new Set(values).size !== values.length || values.some((role) => !roles.includes(role)))
      throw new TypeError("Select one or more unique theme roles");
    return Object.freeze([...values]);
  };
  const colors = Object.fromEntries(
    roles.map((role) => [
      role,
      createColorStore(themeColor(theme.getSnapshot().theme, role))
    ])
  );
  let selected = validate(options.roles ?? roles), active = options.activeRole ?? selected[0], view = options.view ?? "shared-wheel";
  if (!selected.includes(active) || !themePickerViews.includes(view))
    throw new TypeError("Invalid active role or picker view");
  const listeners = /* @__PURE__ */ new Set(), colorListeners = /* @__PURE__ */ new Set();
  const capture = () => Object.freeze({
    roles: selected,
    activeRole: active,
    view,
    colors: Object.freeze(
      Object.fromEntries(
        roles.map((role) => [role, colors[role].getSnapshot()])
      )
    )
  });
  let snapshot = capture(), syncing = false, mounts = 0, unsubscribe;
  const server = snapshot, serverColor = colors[active].getServerSnapshot();
  const publish = () => {
    snapshot = capture();
    listeners.forEach((fn) => fn());
    colorListeners.forEach((fn) => fn());
  };
  for (const role of roles)
    colors[role].subscribe(() => {
      if (syncing) return;
      const hex = colors[role].getSnapshot().hex;
      if (themeColor(theme.getSnapshot().theme, role) !== hex)
        theme.setColor(role, hex);
      publish();
    });
  const sync = () => {
    const current = theme.getSnapshot().theme;
    let changed = false;
    syncing = true;
    try {
      for (const role of roles) {
        const hex = themeColor(current, role);
        if (hex !== colors[role].getSnapshot().hex) {
          colors[role].setHex(hex);
          changed = true;
        }
      }
    } finally {
      syncing = false;
    }
    if (changed) publish();
  };
  const selectRole = (role) => {
    if (!selected.includes(role))
      throw new TypeError("Role is not included in this picker");
    if (active !== role) {
      active = role;
      publish();
    }
  };
  return {
    getSnapshot: () => snapshot,
    getServerSnapshot: () => server,
    subscribe(fn) {
      listeners.add(fn);
      return () => {
        listeners.delete(fn);
      };
    },
    mount() {
      if (mounts++ === 0) {
        sync();
        unsubscribe = theme.subscribe(sync);
      }
      let disposed = false;
      return () => {
        if (!disposed) {
          disposed = true;
          if (--mounts === 0) {
            unsubscribe?.();
            unsubscribe = void 0;
          }
        }
      };
    },
    selectRole,
    setRoles(values) {
      selected = validate(values);
      if (!selected.includes(active)) active = selected[0];
      publish();
    },
    setView(value) {
      if (!themePickerViews.includes(value))
        throw new TypeError("Invalid picker view");
      if (view !== value) {
        view = value;
        publish();
      }
    },
    setHSV(role, hsv) {
      if (!selected.includes(role))
        throw new TypeError("Role is not included in this picker");
      colors[role].setHSV(hsv);
    },
    activeColor: {
      getSnapshot: () => colors[active].getSnapshot(),
      getServerSnapshot: () => serverColor,
      getColor: () => colors[active].getColor(),
      getValue: (format) => colors[active].getValue(format),
      subscribe(fn) {
        colorListeners.add(fn);
        return () => {
          colorListeners.delete(fn);
        };
      },
      setAlpha: (alpha) => colors[active].setAlpha(alpha),
      setHex: (hex) => colors[active].setHex(hex),
      setHSV: (hsv) => colors[active].setHSV(hsv),
      setFormat: (format) => colors[active].setFormat(format),
      setView: (value) => colors[active].setView(value)
    }
  };
}
var sharedWheelStyle = () => wheelStyle({ h: 0, s: 100, v: 100 });
function themeMarkerStyle(color, active) {
  const a = color.h * Math.PI / 180;
  return `left:${50 + Math.cos(a) * color.s / 2}%;top:${50 + Math.sin(a) * color.s / 2}%;background:${color.hex};z-index:${active ? 2 : 1}`;
}
function bindThemeWheel(element, picker) {
  return bindMarkerWheel(element, {
    getMarkers: () => themePickerMarkers(picker.getSnapshot()),
    getActiveId: () => picker.getSnapshot().activeRole,
    select: (id) => picker.selectRole(id),
    setHSV: (id, hsv) => picker.setHSV(id, hsv)
  });
}
function themePickerMarkers(state) {
  return state.roles.map((role) => ({
    id: role,
    color: state.colors[role],
    label: state.roles.length === 1 ? "" : role[0].toUpperCase(),
    ariaLabel: `Select ${role} marker`
  }));
}

// packages/theme-kit/core/configuration.ts
var configurations = /* @__PURE__ */ new WeakMap();
function themeConfiguration(state, selection) {
  const key = JSON.stringify([state.mode, state.modePreference, state.systemMode, selection]);
  const existing = configurations.get(state.theme)?.get(key);
  if (existing) return existing;
  const tokens = selection ? selectThemeTokens(state.theme, { mode: state.mode, ...selection }) : Object.freeze(themeVariables(state.theme, state.mode));
  const result = Object.freeze({
    theme: state.theme,
    mode: state.mode,
    modePreference: state.modePreference,
    systemMode: state.systemMode,
    tokens,
    css: Object.entries(tokens).map(([key2, value]) => `${key2}:${value}`).join(";"),
    json: JSON.stringify({ theme: state.theme, mode: state.modePreference, systemMode: state.systemMode }, null, 2)
  });
  if (Object.isFrozen(state.theme)) {
    const cache = configurations.get(state.theme) ?? /* @__PURE__ */ new Map();
    if (cache.size >= 16) cache.delete(cache.keys().next().value);
    cache.set(key, result);
    configurations.set(state.theme, cache);
  }
  return result;
}
function themeList(themes) {
  const result = themes.map(parseTheme);
  if (new Set(result.map((theme) => theme.id)).size !== result.length)
    throw new TypeError("Theme list IDs must be unique");
  return Object.freeze(result);
}
function selectedThemeId(theme, themes) {
  const candidate = themes.find((value) => value.id === theme.id);
  return candidate && JSON.stringify(candidate) === JSON.stringify(theme) ? candidate.id : void 0;
}
export {
  bindThemeWheel,
  browserModeStorage,
  browserStorage,
  createHttpThemeLoader,
  createThemePickerStore,
  createThemeStore,
  defaultTheme,
  fromLegacyTheme,
  generateBackground,
  generatePalette,
  generateTheme,
  generateThemeTokens,
  harmonies,
  harmonyColors,
  isModePreference,
  modePreferences,
  mountThemeMode,
  mountThemeStore,
  nextThemeMode,
  parseTheme,
  roles,
  selectThemeTokens,
  selectedThemeId,
  shades,
  sharedWheelStyle,
  suggestedThemeName,
  targets,
  themeColor,
  themeConfiguration,
  themeList,
  themeMarkerStyle,
  themeModeActions,
  themePickerMarkers,
  themePickerViews,
  themeStyle,
  themeVariables,
  toLegacyTheme,
  watchThemeUpdates,
  withThemeBackground,
  withThemeBorder,
  withThemeColor,
  withThemeName
};
//# sourceMappingURL=index.js.map
