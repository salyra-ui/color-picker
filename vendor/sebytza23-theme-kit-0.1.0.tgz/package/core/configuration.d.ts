import type { Theme, ThemeSnapshot, Mode, ModePreference } from './types.js';
import { type TokenSelection } from './editor.js';
export interface ThemeConfiguration {
    readonly theme: Theme;
    readonly mode: Mode;
    readonly modePreference: ModePreference;
    readonly systemMode: Mode;
    readonly tokens: Readonly<Record<string, string>>;
    readonly css: string;
    /** Round-trippable theme + selected mode, suitable for saving to an API. */
    readonly json: string;
}
export type ThemeExportFormat = 'json' | 'css';
export declare function themeConfiguration(state: ThemeSnapshot, selection?: TokenSelection): ThemeConfiguration;
/** A list may change over time; validate IDs so selection is unambiguous. */
export declare function themeList(themes: readonly Theme[]): readonly Theme[];
export declare function selectedThemeId(theme: Theme, themes: readonly Theme[]): string | undefined;
