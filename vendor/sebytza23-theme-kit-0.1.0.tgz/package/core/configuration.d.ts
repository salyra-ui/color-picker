import { type Theme, type ThemeSnapshot, type Mode, type ModePreference, type Role, type Target, type Palette } from './types.js';
import { type TokenSelection } from './editor.js';
export interface SelectedTheme {
    readonly id: string;
    readonly name: string;
    readonly nameSource?: Theme['nameSource'];
    readonly backgroundMode?: Theme['backgroundMode'];
    readonly structure: {
        readonly userPreset?: Readonly<Partial<Record<Role, Palette>>>;
        readonly websitePreset?: {
            readonly background?: Readonly<Partial<Record<Mode, string>>>;
            readonly foreground?: Readonly<Partial<Record<Mode, string>>>;
            readonly border?: Readonly<Partial<Record<'width' | 'radius', Readonly<Partial<Record<Target, number>>>>>>;
        };
    };
}
export interface ThemeConfiguration {
    /** Only selected fields when an export selection is configured. */
    readonly theme: SelectedTheme;
    /** Complete internal context for application rendering, not serialized in JSON. */
    readonly sourceTheme: Theme;
    readonly mode: Mode;
    readonly modePreference: ModePreference;
    readonly systemMode: Mode;
    readonly tokens: Readonly<Record<string, string>>;
    readonly css: string;
    /** Selected theme fields and mode. Merge partial exports with mergeThemeConfiguration(). */
    readonly json: string;
}
export type ThemeExportFormat = 'json' | 'css';
export declare function themeConfiguration(state: ThemeSnapshot, selection?: TokenSelection): ThemeConfiguration;
/** Applies a selected export over a full theme, validating the merged result. */
export declare function mergeThemeConfiguration(base: Theme, value: string | {
    theme: SelectedTheme;
}): Theme;
/** A list may change over time; validate IDs so selection is unambiguous. */
export declare function themeList(themes: readonly Theme[]): readonly Theme[];
export declare function selectedThemeId(theme: Theme, themes: readonly Theme[]): string | undefined;
