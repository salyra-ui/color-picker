import { type ColorMarker, type ColorStore, type ColorSnapshot, type HSV } from '@sebytza23/color-picker';
import { type Role, type ThemeStore } from './types.js';
export declare const themePickerViews: readonly ["area", "wheel", "shared-wheel"];
export type ThemePickerView = (typeof themePickerViews)[number];
export interface ThemePickerSnapshot {
    readonly roles: readonly Role[];
    readonly activeRole: Role;
    readonly view: ThemePickerView;
    readonly colors: Readonly<Record<Role, ColorSnapshot>>;
}
export interface ThemePickerOptions {
    disabled?: boolean;
    /** Hide role and view selectors for a fixed composition. Defaults to false for one role. */
    controls?: boolean;
    roles?: readonly Role[];
    activeRole?: Role;
    view?: ThemePickerView;
}
export interface ThemePickerStore {
    getSnapshot(): ThemePickerSnapshot;
    getServerSnapshot(): ThemePickerSnapshot;
    subscribe(fn: () => void): () => void;
    /** Start external theme synchronization on mount; cleanup is safe to remount. */
    mount(): () => void;
    setRoles(roles: readonly Role[]): void;
    selectRole(role: Role): void;
    setView(view: ThemePickerView): void;
    setHSV(role: Role, hsv: Partial<HSV>): void;
    readonly activeColor: ColorStore;
}
export declare function createThemePickerStore(theme: ThemeStore, options?: ThemePickerOptions): ThemePickerStore;
export declare const sharedWheelStyle: () => string;
export declare function themeMarkerStyle(color: ColorSnapshot, active: boolean): string;
/** Theme adapter: geometry, gestures and marker rendering belong to color-picker. */
export declare function bindThemeWheel(element: HTMLElement, picker: ThemePickerStore): () => void;
export declare function themePickerMarkers(state: ThemePickerSnapshot): readonly ColorMarker[];
