import { type Role, type Theme, type Target, type BorderKind, type Mode, type Harmony } from './types.js';
/** Updates one palette. Manually selected sibling colors remain untouched. */
export declare function withThemeColor(theme: Theme, role: Role, input: string): Theme;
export declare function withThemeBorder(theme: Theme, kind: BorderKind, target: Target, value: number): Theme;
export declare function themeColor(theme: Theme, role: Role): string;
export interface TokenSelection {
    /** Omitted means primary only; [] exports no color palettes. */
    roles?: readonly Role[];
    width?: readonly Target[];
    radius?: readonly Target[];
    background?: boolean;
    mode?: Mode;
    /** Background modes included in JSON. Defaults to the resolved active mode. */
    modes?: readonly Mode[];
}
/** Exports exactly the requested tokens, without unrelated colors/borders. */
export declare function selectThemeTokens(theme: Theme, selection?: TokenSelection): Readonly<Record<string, string>>;
export declare function generateThemeTokens(seed: string, options?: TokenSelection & {
    harmony?: Harmony;
}): Readonly<Record<string, string>>;
export declare function suggestedThemeName(theme: Theme): string;
export declare function withThemeName(theme: Theme, name?: string): Theme;
