import type { ThemeOptions, ThemeStorage, ThemeStore } from './types.js';
export declare function createThemeStore(options?: ThemeOptions): ThemeStore;
/** Debounced optional persistence; provider cleanup cancels I/O and flushes the last theme. */
export declare function mountThemeStore(store: ThemeStore, storage?: ThemeStorage, options?: Pick<ThemeOptions, 'revalidateOnFocus' | 'revalidateIntervalMs' | 'modeStorage'>): () => void;
/** Constructing this adapter on the server is safe; browser access happens on mount. */
export declare function browserStorage(key?: string): ThemeStorage;
