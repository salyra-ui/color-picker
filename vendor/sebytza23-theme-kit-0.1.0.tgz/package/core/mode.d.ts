import { type ModePreference, type ModeStorage, type ThemeStore } from './types.js';
export declare function isModePreference(value: unknown): value is ModePreference;
export declare function nextThemeMode(mode: ModePreference): ModePreference;
/** Lazy browser adapter: safe to construct during SSR. */
export declare function browserModeStorage(key?: string): ModeStorage;
/** Resolve system only after mount, retaining the deterministic SSR snapshot. */
export declare function mountThemeMode(store: ThemeStore, storage?: ModeStorage | false): () => void;
/** Framework-independent actions for custom buttons, selects and toggles. */
export declare function themeModeActions(store: ThemeStore): {
    setMode: (mode: ModePreference) => void;
    cycle: () => void;
};
