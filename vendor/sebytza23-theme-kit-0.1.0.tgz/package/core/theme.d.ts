import { type Harmony, type BackgroundMode, type Theme, type Palette, type Role, type ThemeStructure, type Mode } from './types.js';
export declare function generatePalette(seed: string): Palette;
export declare function generateTheme(seed: string, options?: {
    id?: string;
    name?: string;
    base?: Theme;
    background?: BackgroundMode;
    roles?: readonly Role[];
    harmony?: Harmony;
}): Theme;
/** Validate, copy and freeze at trust boundaries; strip unknown keys. */
export declare function parseTheme(value: unknown): Theme;
/** Import an existing MyUniversity /v1/theme record, including JSON Structure. */
export declare function fromLegacyTheme(value: unknown): Theme;
export declare function toLegacyTheme(theme: Theme): {
    ThemeID: string;
    Name: string;
    Structure: ThemeStructure;
};
export declare function themeVariables(theme: Theme, mode?: Mode): Record<string, string>;
export declare function themeStyle(theme: Theme, mode?: Mode): string;
export declare const defaultTheme: Theme;
/** Subtle primary hue in both surfaces, gamut-mapped to sRGB for legacy HSL tokens. */
export declare function generateBackground(seed: string, mode: Exclude<BackgroundMode, 'preserve'>): Pick<ThemeStructure['websitePreset'], 'background' | 'foreground'>;
export declare function withThemeBackground(theme: Theme, mode: Exclude<BackgroundMode, 'preserve'>): Theme;
/** Hue-wheel harmonies, retaining the primary saturation and brightness. */
export declare function harmonyColors(seed: string, harmony?: Harmony): Record<Role, string>;
