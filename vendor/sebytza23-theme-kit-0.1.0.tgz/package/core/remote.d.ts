import type { Theme, ThemeStore } from './types.js';
export interface HttpThemeLoaderOptions {
    fetch?: typeof fetch;
    headers?: HeadersInit;
    credentials?: RequestCredentials;
}
/** Per-provider conditional HTTP loader. Construct safely on the server; fetch is deferred. */
export declare function createHttpThemeLoader(url: string, options?: HttpThemeLoaderOptions): ((signal: AbortSignal) => Promise<Theme>) & {
    invalidate(): void;
};
export interface ThemeUpdateOptions {
    /** Revalidate when this page becomes active again. */
    onFocus?: boolean;
    intervalMs?: number;
    /** Connect an SSE/WebSocket or other application's theme-changed notification. */
    subscribe?: (invalidate: () => void) => () => void;
}
/** Mount-only watcher; coalesces simultaneous notifications and cleans every listener. */
export declare function watchThemeUpdates(store: ThemeStore, options?: ThemeUpdateOptions): () => void;
