export * from '@sebytza23/theme-kit';
import { type CSSProperties, type ReactNode } from 'react';
import { type ModePreference, type ThemeConfiguration, type ThemeExportFormat, type TokenSelection, type ThemePickerOptions, type ThemePickerStore, type Target, type BorderKind, type ThemeOptions, type ThemeStore, type Theme, type Role, type PaletteOptions } from '@sebytza23/theme-kit';
export declare function useThemeStore(): ThemeStore;
export declare function useTheme(): import(".").ThemeSnapshot;
/** Options initialize this provider. Use store.setTheme for subsequent changes. */
export declare function ThemeProvider({ children, className, style, store: provided, ...options }: ThemeOptions & {
    children: ReactNode;
    className?: string;
    style?: CSSProperties;
    store?: ThemeStore;
}): import("react").JSX.Element;
export declare function ThemeLoading({ children }: {
    children: ReactNode;
}): import("react").JSX.Element | null;
export declare function ThemeReady({ children }: {
    children: ReactNode;
}): import("react").JSX.Element | null;
export declare function ThemeError({ children, }: {
    children: (error: Error, retry: () => Promise<void>) => ReactNode;
}): import("react").JSX.Element | null;
export declare function ThemeSwatch({ theme, children, className, }: {
    theme: Theme;
    children?: ReactNode;
    className?: string;
}): import("react").JSX.Element;
export declare function useThemeMode(): {
    setMode: (mode: ModePreference) => void;
    cycle: () => void;
    preference: "light" | "dark" | "system";
    resolvedMode: import(".").Mode;
};
export declare function ThemeMode({ className, value, children, labels, }: {
    className?: string;
    value?: ModePreference;
    labels?: Record<ModePreference, ReactNode>;
    children?: ReactNode | ((mode: ReturnType<typeof useThemeMode>) => ReactNode);
}): import("react").JSX.Element;
export declare function ThemeName({ label, className, children, }: {
    label?: string;
    className?: string;
    children?: (value: {
        name: string;
        suggestedName: string;
        setName: ThemeStore['setName'];
    }) => ReactNode;
}): import("react").JSX.Element;
export declare function ThemePalette({ role, className, shape, classes, labels, shadeClasses, }: PaletteOptions & {
    role?: Role;
    className?: string;
}): import("react").JSX.Element;
/** Compose your own layout with ColorProvider and useThemeStore().generate if preferred. */
export declare function ThemeGenerator({ role, wheel, disabled, children, className, }: {
    children?: ReactNode;
    role?: Role;
    wheel?: boolean;
    disabled?: boolean;
    className?: string;
}): import("react").JSX.Element;
export declare function ThemeBackground({ label, className, }: {
    label?: string;
    className?: string;
}): import("react").JSX.Element;
export declare const ThemeColor: typeof ThemeGenerator;
export declare function ThemeHarmony({ label }: {
    label?: string;
}): import("react").JSX.Element;
export declare function ThemeBorder({ kind, target, label, }: {
    kind?: BorderKind;
    target?: Target;
    label?: string;
}): import("react").JSX.Element;
export declare function ThemeRadius(props: Omit<Parameters<typeof ThemeBorder>[0], 'kind'>): import("react").JSX.Element;
export declare function ThemeBorderWidth(props: Omit<Parameters<typeof ThemeBorder>[0], 'kind'>): import("react").JSX.Element;
export declare function ThemeWheel({ picker }: {
    picker: ThemePickerStore;
}): import("react").JSX.Element;
export declare function ThemePicker({ picker: provided, children, ...options }: ThemePickerOptions & {
    picker?: ThemePickerStore;
    children?: ReactNode;
}): import("react").JSX.Element;
export declare function ThemeSelect({ themes, label, className, }: {
    themes: readonly Theme[];
    label?: string;
    className?: string;
}): import("react").JSX.Element;
export declare function ThemeExport({ format, selection, onChange, children, className, }: {
    format?: ThemeExportFormat;
    selection?: TokenSelection;
    onChange?: (configuration: ThemeConfiguration) => void;
    children?: (configuration: ThemeConfiguration) => ReactNode;
    className?: string;
}): import("react").JSX.Element;
