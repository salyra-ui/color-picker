"use client";
"use client";

// packages/theme-kit/react/index.tsx
export * from '@sebytza23/theme-kit';
import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  useSyncExternalStore
} from "react";
import {
  ColorSurface,
  ColorViewSelect,
  ColorWheel,
  ColorFormatSelect,
  ColorMode,
  ColorProvider,
  ColorArea,
  ColorSlider,
  ColorInput
} from "@sebytza23/color-picker-react";
import { channelsToHex } from "@sebytza23/color-picker";
import {
  themeModeActions,
  suggestedThemeName,
  themeList,
  selectedThemeId,
  themeConfiguration,
  themePickerMarkers,
  createThemePickerStore,
  themePickerViews,
  roles as allRoles,
  harmonies,
  createThemeStore,
  mountThemeStore,
  shades
} from '@sebytza23/theme-kit';
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
var Context = createContext(null);
function useThemeStore() {
  const store = useContext(Context);
  if (!store) throw new Error("Theme components require ThemeProvider");
  return store;
}
function useTheme() {
  const store = useThemeStore();
  return useSyncExternalStore(
    store.subscribe,
    store.getSnapshot,
    store.getServerSnapshot
  );
}
function ThemeProvider({
  children,
  className = "",
  style,
  store: provided,
  ...options
}) {
  const [initial] = useState(options);
  const [store] = useState(() => provided ?? createThemeStore(initial));
  useEffect(
    () => mountThemeStore(store, initial.storage, initial),
    [store, initial]
  );
  return /* @__PURE__ */ jsx(Context.Provider, { value: store, children: /* @__PURE__ */ jsx(ThemeScope, { className, style, children }) });
}
function ThemeScope({
  children,
  className,
  style
}) {
  const state = useTheme();
  const variables = Object.fromEntries(
    state.style.split(";").map((p) => {
      const i = p.indexOf(":");
      return [
        p.slice(0, i) === "color-scheme" ? "colorScheme" : p.slice(0, i),
        p.slice(i + 1)
      ];
    })
  );
  return /* @__PURE__ */ jsx(
    "div",
    {
      "data-disabled": state.disabled,
      "data-theme": state.theme.id,
      "data-mode": state.mode,
      "data-mode-preference": state.modePreference,
      "data-theme-status": state.status,
      className: `tk-scope ${className}`,
      style: { ...variables, ...style },
      children: /* @__PURE__ */ jsx(
        "fieldset",
        {
          className: "tk-provider-controls",
          disabled: state.disabled,
          ...state.disabled ? { inert: "" } : {},
          "aria-disabled": state.disabled,
          children
        }
      )
    }
  );
}
function ThemeLoading({ children }) {
  return useTheme().status === "loading" ? /* @__PURE__ */ jsx(Fragment, { children }) : null;
}
function ThemeReady({ children }) {
  return useTheme().status !== "loading" ? /* @__PURE__ */ jsx(Fragment, { children }) : null;
}
function ThemeError({
  children
}) {
  const state = useTheme(), store = useThemeStore();
  return state.error ? /* @__PURE__ */ jsx(Fragment, { children: children(state.error, store.reload) }) : null;
}
function ThemeSwatch({
  theme,
  children = theme.name,
  className = ""
}) {
  const store = useThemeStore(), state = useTheme();
  return /* @__PURE__ */ jsx(
    "button",
    {
      type: "button",
      className,
      "aria-pressed": state.theme.id === theme.id,
      onClick: () => store.setTheme(theme),
      children
    }
  );
}
function useThemeMode() {
  const state = useTheme(), store = useThemeStore();
  return {
    preference: state.modePreference,
    resolvedMode: state.mode,
    ...themeModeActions(store)
  };
}
function ThemeMode({
  className = "",
  value,
  children,
  labels = { system: "System", light: "Light mode", dark: "Dark mode" }
}) {
  const mode = useThemeMode();
  return /* @__PURE__ */ jsx(
    "button",
    {
      type: "button",
      className,
      "aria-pressed": value ? mode.preference === value : void 0,
      onClick: () => value ? mode.setMode(value) : mode.cycle(),
      children: typeof children === "function" ? children(mode) : children ?? labels[value ?? mode.preference]
    }
  );
}
function ThemeName({
  label = "Theme name",
  className = "",
  children
}) {
  const state = useTheme(), store = useThemeStore(), suggestion = suggestedThemeName(state.theme);
  if (children)
    return /* @__PURE__ */ jsx(Fragment, { children: children({
      name: state.theme.name,
      suggestedName: suggestion,
      setName: store.setName
    }) });
  return /* @__PURE__ */ jsxs("label", { className: `tk-name ${className}`, children: [
    label,
    /* @__PURE__ */ jsx(
      "input",
      {
        maxLength: 200,
        value: state.theme.name,
        placeholder: suggestion,
        onBlur: (e) => {
          if (!e.target.value) store.setName();
        },
        onChange: (e) => store.setName(e.target.value)
      }
    ),
    /* @__PURE__ */ jsxs("small", { children: [
      "Suggested: ",
      suggestion
    ] })
  ] });
}
function ThemePalette({
  role = "primary",
  className = "",
  shape = "square",
  classes = {},
  labels = {},
  shadeClasses = {}
}) {
  const state = useTheme();
  return /* @__PURE__ */ jsx(
    "div",
    {
      className: `tk-palette ${classes.root ?? ""} ${className}`,
      "data-shape": shape,
      "aria-label": `${role} shades`,
      children: shades.map((shade) => /* @__PURE__ */ jsxs(
        "div",
        {
          "data-palette-part": "item",
          className: `${classes.item ?? ""} ${shadeClasses[shade] ?? ""}`,
          children: [
            /* @__PURE__ */ jsx("span", { "data-palette-part": "label", className: classes.label, children: labels[shade] ?? shade }),
            /* @__PURE__ */ jsx(
              "div",
              {
                "data-palette-part": "swatch",
                className: `tk-shade ${classes.swatch ?? ""}`,
                style: {
                  background: `hsl(${state.theme.structure.userPreset[role][shade]})`
                }
              }
            )
          ]
        },
        shade
      ))
    }
  );
}
function ThemeGenerator({
  role = "primary",
  wheel = false,
  disabled = false,
  children,
  className = ""
}) {
  const state = useTheme(), store = useThemeStore();
  useEffect(() => {
    const fields = store.registerFields({ roles: [role] });
    return fields.destroy;
  }, [store, role]);
  return /* @__PURE__ */ jsx(
    ColorProvider,
    {
      disabled: disabled || state.disabled,
      view: wheel ? "wheel" : "area",
      value: channelsToHex(state.theme.structure.userPreset[role].DEFAULT),
      onChange: (hex) => store.setColor(role, hex),
      children: /* @__PURE__ */ jsx("div", { className: `tk-generator ${className}`, children: children ?? /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx(ColorViewSelect, {}),
        /* @__PURE__ */ jsx(ColorSurface, {}),
        /* @__PURE__ */ jsx(ColorFormatSelect, {}),
        /* @__PURE__ */ jsx(ColorInput, {}),
        /* @__PURE__ */ jsx(ColorMode, {})
      ] }) })
    }
  );
}
function ThemeBackground({
  label = "Tint background with primary",
  className = ""
}) {
  const state = useTheme(), store = useThemeStore();
  useEffect(() => {
    const fields = store.registerFields({ roles: [], background: true });
    return fields.destroy;
  }, [store]);
  return /* @__PURE__ */ jsxs("label", { className: `tk-background ${className}`, children: [
    /* @__PURE__ */ jsx(
      "input",
      {
        type: "checkbox",
        checked: state.background === "tinted",
        onChange: (e) => store.setBackground(e.target.checked ? "tinted" : "neutral")
      }
    ),
    label
  ] });
}
var ThemeColor = ThemeGenerator;
function ThemeHarmony({ label = "Color harmony" }) {
  const state = useTheme(), store = useThemeStore();
  return /* @__PURE__ */ jsxs("div", { className: "tk-harmony", children: [
    /* @__PURE__ */ jsxs("label", { children: [
      label,
      /* @__PURE__ */ jsx(
        "select",
        {
          value: state.theme.harmony ?? "analogous",
          onChange: (e) => store.setHarmony(e.target.value),
          children: harmonies.map((value) => /* @__PURE__ */ jsx("option", { value, children: value }, value))
        }
      )
    ] }),
    /* @__PURE__ */ jsx("button", { type: "button", onClick: () => store.generateHarmony(), children: "Generate accent & secondary" })
  ] });
}
function ThemeBorder({
  kind = "width",
  target = "DEFAULT",
  label
}) {
  const state = useTheme(), store = useThemeStore(), value = state.theme.structure.websitePreset.border[kind][target];
  useEffect(() => {
    const fields = store.registerFields({ roles: [], [kind]: [target] });
    return fields.destroy;
  }, [store, kind, target]);
  return /* @__PURE__ */ jsxs("label", { className: "tk-border", children: [
    label ?? `${target} border ${kind}`,
    /* @__PURE__ */ jsx(
      "input",
      {
        type: "number",
        min: 0,
        max: 1e3,
        step: kind === "width" ? 1 : 0.125,
        value,
        onChange: (e) => {
          const n = e.currentTarget.valueAsNumber;
          if (Number.isFinite(n) && n >= 0 && n <= 1e3)
            store.setBorder(kind, target, n);
        }
      }
    ),
    kind === "width" ? "px" : "rem"
  ] });
}
function ThemeRadius(props) {
  return /* @__PURE__ */ jsx(ThemeBorder, { ...props, kind: "radius" });
}
function ThemeBorderWidth(props) {
  return /* @__PURE__ */ jsx(ThemeBorder, { ...props, kind: "width" });
}
function ThemeWheel({ picker }) {
  const state = useSyncExternalStore(
    picker.subscribe,
    picker.getSnapshot,
    picker.getServerSnapshot
  );
  return /* @__PURE__ */ jsx(
    ColorWheel,
    {
      className: "tk-shared-wheel",
      label: "Shared theme color wheel",
      markers: themePickerMarkers(state),
      activeId: state.activeRole,
      onSelect: (id) => picker.selectRole(id),
      onMarkerChange: (id, hsv) => picker.setHSV(id, hsv)
    }
  );
}
function ThemePicker({
  picker: provided,
  children,
  ...options
}) {
  const theme = useThemeStore(), [picker] = useState(
    () => provided ?? createThemePickerStore(theme, options)
  );
  const state = useSyncExternalStore(
    picker.subscribe,
    picker.getSnapshot,
    picker.getServerSnapshot
  );
  useEffect(() => picker.mount(), [picker]);
  return /* @__PURE__ */ jsx(ColorProvider, { store: picker.activeColor, children: /* @__PURE__ */ jsxs("div", { className: "tk-picker tk-generator", children: [
    /* @__PURE__ */ jsxs(
      "label",
      {
        className: "cp-format",
        hidden: options.controls === false || options.controls === void 0 && options.roles?.length === 1,
        children: [
          "Theme picker view",
          /* @__PURE__ */ jsx(
            "select",
            {
              value: state.view,
              onChange: (e) => picker.setView(e.target.value),
              children: themePickerViews.map((view) => /* @__PURE__ */ jsx("option", { value: view, children: view === "area" ? "Rectangle" : view === "wheel" ? "Wheel" : "Shared wheel" }, view))
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ jsxs(
      "fieldset",
      {
        className: "tk-role-options",
        hidden: options.controls === false || options.controls === void 0 && options.roles?.length === 1,
        children: [
          /* @__PURE__ */ jsx("legend", { children: "Visible roles" }),
          allRoles.map((role) => /* @__PURE__ */ jsxs("label", { children: [
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "checkbox",
                checked: state.roles.includes(role),
                disabled: state.roles.length === 1 && state.roles.includes(role),
                onChange: (e) => picker.setRoles(
                  e.target.checked ? [...state.roles, role] : state.roles.filter((r) => r !== role)
                )
              }
            ),
            role
          ] }, role))
        ]
      }
    ),
    /* @__PURE__ */ jsx(
      "div",
      {
        className: "tk-role-tabs",
        "aria-label": "Active color",
        hidden: state.roles.length === 1,
        children: state.roles.map((role) => /* @__PURE__ */ jsxs(
          "button",
          {
            type: "button",
            "aria-pressed": state.activeRole === role,
            onClick: () => picker.selectRole(role),
            children: [
              /* @__PURE__ */ jsx("span", { style: { background: state.colors[role].hex } }),
              role
            ]
          },
          role
        ))
      }
    ),
    state.view === "shared-wheel" ? /* @__PURE__ */ jsx(ThemeWheel, { picker }) : state.view === "wheel" ? /* @__PURE__ */ jsx(ColorWheel, {}) : /* @__PURE__ */ jsx(ColorArea, {}),
    /* @__PURE__ */ jsxs("p", { className: "tk-editing", "aria-live": "polite", children: [
      "Editing ",
      state.activeRole
    ] }),
    children ?? /* @__PURE__ */ jsxs(Fragment, { children: [
      /* @__PURE__ */ jsx(ColorSlider, { channel: state.view === "area" ? "h" : "v" }),
      /* @__PURE__ */ jsx(ColorFormatSelect, {}),
      /* @__PURE__ */ jsx(ColorInput, {}),
      /* @__PURE__ */ jsx(ColorMode, {})
    ] })
  ] }) });
}
function ThemeSelect({
  themes,
  label = "Saved themes",
  className = ""
}) {
  const store = useThemeStore(), state = useTheme(), list = themeList(themes), value = selectedThemeId(state.theme, list) ?? "";
  return /* @__PURE__ */ jsxs("label", { className: `cp-format tk-select ${className}`, children: [
    label,
    /* @__PURE__ */ jsxs(
      "select",
      {
        value,
        disabled: !list.length,
        onChange: (e) => {
          const theme = list.find((theme2) => theme2.id === e.target.value);
          if (theme) store.setTheme(theme);
        },
        children: [
          /* @__PURE__ */ jsx("option", { value: "", disabled: true, children: list.length ? "Custom theme" : "No themes available" }),
          list.map((theme) => /* @__PURE__ */ jsx("option", { value: theme.id, children: theme.name }, theme.id))
        ]
      }
    )
  ] });
}
function ThemeExport({
  format = "json",
  selection,
  onChange,
  children,
  className = ""
}) {
  const state = useTheme(), configuration = themeConfiguration(state, selection), selectionKey = JSON.stringify(selection), callback = useRef(onChange);
  callback.current = onChange;
  useEffect(
    () => callback.current?.(themeConfiguration(state, selection)),
    [
      state.theme,
      state.mode,
      state.modePreference,
      state.systemMode,
      selectionKey
    ]
  );
  return children ? /* @__PURE__ */ jsx(Fragment, { children: children(configuration) }) : /* @__PURE__ */ jsx("pre", { className: `tk-export ${className}`, "aria-label": "Theme configuration", children: configuration[format] });
}
export {
  ThemeBackground,
  ThemeBorder,
  ThemeBorderWidth,
  ThemeColor,
  ThemeError,
  ThemeExport,
  ThemeGenerator,
  ThemeHarmony,
  ThemeLoading,
  ThemeMode,
  ThemeName,
  ThemePalette,
  ThemePicker,
  ThemeProvider,
  ThemeRadius,
  ThemeReady,
  ThemeSelect,
  ThemeSwatch,
  ThemeWheel,
  useTheme,
  useThemeMode,
  useThemeStore
};
//# sourceMappingURL=index.js.map
