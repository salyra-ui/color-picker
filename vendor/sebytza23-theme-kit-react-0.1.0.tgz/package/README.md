# @sebytza23/theme-kit-react

Install only this adapter and its core dependencies.

`npm install @sebytza23/theme-kit-react`

Documentation: https://sebytza23.github.io/theme-kit/docs.html

Browser scripts are in browser/ for vanilla HTML and PHP; no framework is required.
