# @sebytza23/theme-kit-svelte

Install only this adapter and its core dependencies.

`npm install @sebytza23/theme-kit-svelte`

Documentation: https://sebytza23.github.io/theme-kit/docs.html

Browser scripts are in browser/ for vanilla HTML and PHP; no framework is required.
