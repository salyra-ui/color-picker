<script lang="ts">
  import type { Target } from '@sebytza23/theme-kit';
  import ThemeBorder from './ThemeBorder.svelte';
  let props: { target?: Target; label?: string } = $props();
</script>

<ThemeBorder {...props} kind="width" />
